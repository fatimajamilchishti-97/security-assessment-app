'use client';

import { useSocket } from '@/contexts/SocketContext';
import { useState, useEffect } from 'react';
import {
  AttackType, AttackConfig, VictimDevice, AttackState, ATTACK_LABELS, ATTACK_DESCRIPTIONS,
  ATTACK_SEVERITY, CredentialEntry, CookieEntry, SessionEntry, DNSQueryEntry,
} from '@/types';
import {
  Crosshair, Play, Shield, ChevronDown, ChevronUp, Eye, Key, Cookie,
  Globe, AlertTriangle, Info,
} from 'lucide-react';

const ATTACK_TYPES: AttackType[] = [
  'arp_spoof', 'dns_spoof', 'ssl_strip', 'session_hijack', 'packet_sniff', 'fake_login', 'cookie_steal',
];

const SEVERITY_COLORS = {
  critical: 'bg-red-500/20 text-red-400 border-red-500/30',
  high: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  low: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
};

export default function AttacksPage() {
  const { socket } = useSocket();
  const [victims, setVictims] = useState<VictimDevice[]>([]);
  const [selectedVictim, setSelectedVictim] = useState<string>('');
  const [config, setConfig] = useState<AttackConfig>({
    aggressiveness: 'medium',
    duration: 30,
    autoStop: true,
    stealth: false,
  });
  const [credentials, setCredentials] = useState<CredentialEntry[]>([]);
  const [cookies, setCookies] = useState<CookieEntry[]>([]);
  const [sessions, setSessions] = useState<SessionEntry[]>([]);
  const [dnsQueries, setDnsQueries] = useState<DNSQueryEntry[]>([]);
  const [activeAttacks, setActiveAttacks] = useState<AttackState[]>([]);
  const [expandedAttack, setExpandedAttack] = useState<AttackType | null>(null);
  const [activeTab, setActiveTab] = useState<'creds' | 'cookies' | 'sessions' | 'dns'>('creds');

  useEffect(() => {
    const onVictims = (v: VictimDevice[]) => {
      setVictims(v);
      setSelectedVictim((cur) => cur || (v.length > 0 ? v[0].id : ''));
    };
    const onVictimStatus = (v: VictimDevice) => {
      setVictims((prev) => prev.map((d) => (d.id === v.id ? v : d)));
    };
    const onData = (_id: string, data: Partial<{ credentials: CredentialEntry[]; cookies: CookieEntry[]; sessions: SessionEntry[]; dnsQueries: DNSQueryEntry[] }>) => {
      if (data.credentials) setCredentials((p) => [...p, ...data.credentials!]);
      if (data.cookies) setCookies((p) => [...p, ...data.cookies!]);
      if (data.sessions) setSessions((p) => [...p, ...data.sessions!]);
      if (data.dnsQueries) setDnsQueries((p) => [...p, ...data.dnsQueries!]);
    };
    const onLaunched = (a: AttackState) => setActiveAttacks((p) => [...p, a]);
    const onStopped = (id: string) => setActiveAttacks((p) => p.filter((a) => a.id !== id));
    const onMitigated = (id: string) => setActiveAttacks((p) => p.filter((a) => a.id !== id));
    socket.on('victims:list', onVictims);
    socket.on('victim:status', onVictimStatus);
    socket.on('data:captured', onData);
    socket.on('attack:launched', onLaunched);
    socket.on('attack:stopped', onStopped);
    socket.on('attack:mitigated', onMitigated);
    socket.emit('victims:request');
    return () => {
      socket.off('victims:list', onVictims);
      socket.off('victim:status', onVictimStatus);
      socket.off('data:captured', onData);
      socket.off('attack:launched', onLaunched);
      socket.off('attack:stopped', onStopped);
      socket.off('attack:mitigated', onMitigated);
    };
  }, [socket]);

  const launchAttack = (type: AttackType) => {
    if (!selectedVictim) return;
    socket.emit('attack:launch', { type, victimId: selectedVictim, config });
  };

  const mitigateAttack = (type: AttackType) => {
    if (!selectedVictim) return;
    const active = activeAttacks.find((a) => a.type === type && a.targetId === selectedVictim);
    if (active) socket.emit('attack:mitigate', active.id);
  };

  const deviceIcon = (type: VictimDevice['type']) => {
    switch (type) {
      case 'laptop': return '💻';
      case 'phone': return '📱';
      case 'tablet': return '📟';
      case 'iot': return '🖨️';
      default: return '🖥️';
    }
  };

  const statusColor = (status: VictimDevice['status']) => {
    switch (status) {
      case 'compromised': return 'bg-[var(--cyber-danger)]';
      case 'active': return 'bg-[var(--cyber-accent)]';
      case 'protected': return 'bg-[var(--cyber-success)]';
      default: return 'bg-[var(--cyber-text-dim)]';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-3">
          <Crosshair className="w-6 h-6 text-[var(--cyber-danger)]" />
          Attack Center
        </h1>
        <p className="text-sm text-[var(--cyber-text-dim)]">Launch simulated MITM attacks against virtual targets</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-3">
          {ATTACK_TYPES.map((type) => (
            <div
              key={type}
              className={`bg-[var(--cyber-surface)] border rounded-lg transition-all duration-300
                ${expandedAttack === type ? 'border-[var(--cyber-primary)] cyber-glow' : 'border-[var(--cyber-border)] hover:border-[var(--cyber-primary)]/30'}`}
            >
              <div
                className="p-4 flex items-center justify-between cursor-pointer"
                onClick={() => setExpandedAttack(expandedAttack === type ? null : type)}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center
                    ${type === 'arp_spoof' || type === 'dns_spoof' ? 'bg-purple-500/20 text-purple-400' :
                      type === 'ssl_strip' || type === 'session_hijack' ? 'bg-red-500/20 text-red-400' :
                      type === 'fake_login' || type === 'cookie_steal' ? 'bg-orange-500/20 text-orange-400' :
                      'bg-cyan-500/20 text-cyan-400'}`}>
                    <Crosshair className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-medium">{ATTACK_LABELS[type]}</h3>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border ${SEVERITY_COLORS[ATTACK_SEVERITY[type]]}`}>
                        {ATTACK_SEVERITY[type].toUpperCase()}
                      </span>
                    </div>
                    <p className="text-xs text-[var(--cyber-text-dim)]">{ATTACK_DESCRIPTIONS[type]}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => { e.stopPropagation(); launchAttack(type); }}
                    className="cyber-btn-primary flex items-center gap-1.5 text-xs"
                  >
                    <Play className="w-3 h-3" /> Launch
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); mitigateAttack(type); }}
                    className="cyber-btn-success flex items-center gap-1.5 text-xs"
                  >
                    <Shield className="w-3 h-3" /> Mitigate
                  </button>
                  {expandedAttack === type ? <ChevronUp className="w-4 h-4 text-[var(--cyber-text-dim)]" /> : <ChevronDown className="w-4 h-4 text-[var(--cyber-text-dim)]" />}
                </div>
              </div>

              {expandedAttack === type && (
                <div className="px-4 pb-4 border-t border-[var(--cyber-border)] pt-3">
                  <div className="bg-[var(--cyber-bg)] rounded-lg p-3 text-xs text-[var(--cyber-text-dim)] space-y-2">
                    <div className="flex items-start gap-2">
                      <Info className="w-3 h-3 mt-0.5 text-[var(--cyber-accent)] flex-shrink-0" />
                      <div>
                        <p className="font-medium text-[var(--cyber-text)] mb-1">How {ATTACK_LABELS[type]} Works</p>
                        {type === 'arp_spoof' && (
                          <p>The attacker sends forged ARP reply packets to the victim, claiming to be the gateway. Simultaneously, the attacker tells the gateway it is the victim. This creates a man-in-the-middle position where all traffic flows through the attacker. The victim&apos;s OS silently updates its ARP cache with the malicious MAC-to-IP mapping.</p>
                        )}
                        {type === 'dns_spoof' && (
                          <p>When the victim queries a DNS server, the attacker intercepts the response and replaces the legitimate IP address with their own. The victim connects to the attacker&apos;s server instead of the real one. This enables phishing, credential harvesting, and malware distribution while the victim sees the correct domain in their browser.</p>
                        )}
                        {type === 'ssl_strip' && (
                          <p>The attacker intercepts the initial HTTP request and acts as a proxy, making the HTTPS connection on behalf of the victim while serving the response over unencrypted HTTP. The victim sees no padlock icon and may not notice the downgrade. All POST data, cookies, and session tokens are exposed in plaintext.</p>
                        )}
                        {type === 'session_hijack' && (
                          <p>By sniffing unencrypted traffic (HTTP, not HTTPS), the attacker captures session tokens transmitted in cookies or URL parameters. These tokens can then be used to make requests to the server as the victim, bypassing authentication entirely. The victim remains logged in, unaware their session has been cloned.</p>
                        )}
                        {type === 'packet_sniff' && (
                          <p>In a shared network (hub, unswitched LAN, or monitor mode on WiFi), the attacker passively captures all frames regardless of destination. On modern switched networks, this requires ARP spoofing or port mirroring first. Encrypted traffic (HTTPS) shows payloads as ciphertext, but metadata (IPs, ports, timing) remains visible.</p>
                        )}
                        {type === 'fake_login' && (
                          <p>The attacker serves a pixel-perfect clone of a legitimate login page, often after DNS spoofing redirects the victim. When the victim enters credentials, they are POSTed to the attacker&apos;s server, which then redirects to the real site. The victim believes they simply mistyped their password on the first attempt.</p>
                        )}
                        {type === 'cookie_steal' && (
                          <p>Through a Cross-Site Scripting (XSS) vulnerability, the attacker injects JavaScript that reads document.cookie and sends it to their server. Cookies without the HttpOnly flag are accessible to client-side scripts. Stolen session cookies allow the attacker to hijack the victim&apos;s authenticated session.</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="w-3 h-3 mt-0.5 text-[var(--cyber-warning)] flex-shrink-0" />
                      <div>
                        <p className="font-medium text-[var(--cyber-warning)] mb-1">Real-World Impact</p>
                        {type === 'arp_spoof' && <p>Used in countless public WiFi attacks and internal network pivots. Detection requires ARP table monitoring or static ARP entries.</p>}
                        {type === 'dns_spoof' && <p>The DNSChanger malware infected 4 million computers (2011). DNSSEC is the primary defense.</p>}
                        {type === 'ssl_strip' && <p>Popularized by Moxie Marlinspike&apos;s sslstrip tool (2009). Still effective against sites without HSTS. Forced HTTPS and HSTS preloading are the countermeasures.</p>}
                        {type === 'session_hijack' && <p>Used in the famous FireSheep Firefox extension (2010) which hijacked Facebook/Twitter sessions on public WiFi. Led to widespread adoption of HTTPS-only cookies.</p>}
                        {type === 'packet_sniff' && <p>Essential technique in every penetration test. Wireshark is the standard tool. Legal when authorized; illegal under wiretapping laws without consent.</p>}
                        {type === 'fake_login' && <p>Phishing accounts for the majority of breaches (Verizon DBIR). Credential stuffing from fake login pages is a top attack vector. MFA is the primary mitigation.</p>}
                        {type === 'cookie_steal' && <p>XSS is ranked in the OWASP Top 10. Cookie stealing via XSS affects millions of websites. HttpOnly, SameSite, and CSP headers are the defenses.</p>}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="space-y-4">
          <div className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-4">
            <h3 className="text-sm font-medium mb-3">Target Selection</h3>
            <select
              value={selectedVictim}
              onChange={(e) => setSelectedVictim(e.target.value)}
              className="cyber-select w-full mb-3"
            >
              <option value="">Select victim...</option>
              {victims.map((v) => (
                <option key={v.id} value={v.id}>
                  {deviceIcon(v.type)} {v.hostname} ({v.ip})
                </option>
              ))}
            </select>
            {selectedVictim && (() => {
              const v = victims.find((d) => d.id === selectedVictim);
              if (!v) return null;
              return (
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${statusColor(v.status)}`} />
                    <span className="text-[var(--cyber-text-dim)]">{v.status.toUpperCase()}</span>
                  </div>
                  <p><span className="text-[var(--cyber-text-dim)]">OS:</span> {v.os}</p>
                  <p><span className="text-[var(--cyber-text-dim)]">MAC:</span> {v.mac}</p>
                  <p><span className="text-[var(--cyber-text-dim)]">Ports:</span> {v.openPorts.join(', ')}</p>
                  <div className="bg-[var(--cyber-danger)]/10 border border-[var(--cyber-danger)]/20 rounded p-2 mt-2">
                    <span className="text-[var(--cyber-danger)]">⚠ {v.vulnerability}</span>
                  </div>
                </div>
              );
            })()}
          </div>

          <div className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-4">
            <h3 className="text-sm font-medium mb-3">Attack Config</h3>
            <div className="space-y-3">
              <div>
                <label className="text-[10px] text-[var(--cyber-text-dim)] uppercase tracking-wider">Aggressiveness</label>
                <select
                  value={config.aggressiveness}
                  onChange={(e) => setConfig({ ...config, aggressiveness: e.target.value as AttackConfig['aggressiveness'] })}
                  className="cyber-select w-full mt-1"
                >
                  <option value="low">Low (slow, stealthy)</option>
                  <option value="medium">Medium (balanced)</option>
                  <option value="high">High (fast, noisy)</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-[var(--cyber-text-dim)] uppercase tracking-wider">Duration (sec)</label>
                <input
                  type="number"
                  value={config.duration}
                  onChange={(e) => setConfig({ ...config, duration: parseInt(e.target.value) || 30 })}
                  className="cyber-input w-full mt-1"
                  min={5}
                  max={300}
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-[var(--cyber-text-dim)]">Auto-stop</span>
                <button
                  onClick={() => setConfig({ ...config, autoStop: !config.autoStop })}
                  className={`w-10 h-5 rounded-full transition-colors ${config.autoStop ? 'bg-[var(--cyber-primary)]' : 'bg-[var(--cyber-border)]'}`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${config.autoStop ? 'translate-x-5' : 'translate-x-0.5'} mt-0.5`} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg">
        <div className="p-4 border-b border-[var(--cyber-border)] flex items-center gap-4 flex-wrap">
          <h3 className="text-sm font-medium">Captured Data</h3>
          <div className="flex gap-1">
            {([
              { key: 'creds' as const, label: 'Credentials', icon: Key, count: credentials.length },
              { key: 'cookies' as const, label: 'Cookies', icon: Cookie, count: cookies.length },
              { key: 'sessions' as const, label: 'Sessions', icon: Eye, count: sessions.length },
              { key: 'dns' as const, label: 'DNS', icon: Globe, count: dnsQueries.length },
            ]).map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs transition-colors
                  ${activeTab === tab.key ? 'bg-[var(--cyber-primary)]/20 text-[var(--cyber-primary)]' : 'text-[var(--cyber-text-dim)] hover:text-white'}`}
              >
                <tab.icon className="w-3 h-3" />
                {tab.label} ({tab.count})
              </button>
            ))}
          </div>
        </div>
        <div className="p-4 max-h-64 overflow-y-auto">
          {activeTab === 'creds' && (
            credentials.length === 0 ? <p className="text-[var(--cyber-text-dim)] text-xs text-center py-4">No credentials captured yet</p> :
            <table className="w-full text-xs">
              <thead><tr className="text-[var(--cyber-text-dim)] text-left">
                <th className="pb-2">Time</th><th className="pb-2">URL</th><th className="pb-2">Username</th><th className="pb-2">Password</th><th className="pb-2">Method</th>
              </tr></thead>
              <tbody>
                {credentials.map((c) => (
                  <tr key={c.id} className="border-t border-[var(--cyber-border)]">
                    <td className="py-1.5 text-[var(--cyber-text-dim)]">{new Date(c.timestamp).toLocaleTimeString()}</td>
                    <td className="py-1.5 text-[var(--cyber-accent)]">{c.url}</td>
                    <td className="py-1.5">{c.username}</td>
                    <td className="py-1.5 text-[var(--cyber-danger)]">{c.password}</td>
                    <td className="py-1.5 text-[var(--cyber-text-dim)]">{c.method}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {activeTab === 'cookies' && (
            cookies.length === 0 ? <p className="text-[var(--cyber-text-dim)] text-xs text-center py-4">No cookies stolen yet</p> :
            <table className="w-full text-xs">
              <thead><tr className="text-[var(--cyber-text-dim)] text-left">
                <th className="pb-2">Domain</th><th className="pb-2">Name</th><th className="pb-2">Value</th><th className="pb-2">Flags</th>
              </tr></thead>
              <tbody>
                {cookies.map((c) => (
                  <tr key={c.id} className="border-t border-[var(--cyber-border)]">
                    <td className="py-1.5 text-[var(--cyber-accent)]">{c.domain}</td>
                    <td className="py-1.5">{c.name}</td>
                    <td className="py-1.5 text-[var(--cyber-danger)] font-mono text-[10px]">{c.value.substring(0, 32)}...</td>
                    <td className="py-1.5">
                      <span className={`mr-1 ${c.httpOnly ? 'text-[var(--cyber-success)]' : 'text-[var(--cyber-danger)]'}`}>
                        {c.httpOnly ? 'HttpOnly✓' : 'HttpOnly✗'}
                      </span>
                      <span className={c.secure ? 'text-[var(--cyber-success)]' : 'text-[var(--cyber-danger)]'}>
                        {c.secure ? 'Secure✓' : 'Secure✗'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {activeTab === 'sessions' && (
            sessions.length === 0 ? <p className="text-[var(--cyber-text-dim)] text-xs text-center py-4">No sessions hijacked yet</p> :
            <table className="w-full text-xs">
              <thead><tr className="text-[var(--cyber-text-dim)] text-left">
                <th className="pb-2">Domain</th><th className="pb-2">Session ID</th><th className="pb-2">User ID</th><th className="pb-2">Expiry</th>
              </tr></thead>
              <tbody>
                {sessions.map((s) => (
                  <tr key={s.id} className="border-t border-[var(--cyber-border)]">
                    <td className="py-1.5 text-[var(--cyber-accent)]">{s.domain}</td>
                    <td className="py-1.5 font-mono text-[var(--cyber-danger)]">{s.sessionId}</td>
                    <td className="py-1.5">{s.userId || 'N/A'}</td>
                    <td className="py-1.5 text-[var(--cyber-text-dim)]">{s.expiry}s</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {activeTab === 'dns' && (
            dnsQueries.length === 0 ? <p className="text-[var(--cyber-text-dim)] text-xs text-center py-4">No DNS queries captured yet</p> :
            <table className="w-full text-xs">
              <thead><tr className="text-[var(--cyber-text-dim)] text-left">
                <th className="pb-2">Query</th><th className="pb-2">Original</th><th className="pb-2">Resolved</th><th className="pb-2">Status</th>
              </tr></thead>
              <tbody>
                {dnsQueries.map((d) => (
                  <tr key={d.id} className="border-t border-[var(--cyber-border)]">
                    <td className="py-1.5 text-[var(--cyber-accent)]">{d.query}</td>
                    <td className="py-1.5 text-[var(--cyber-text-dim)]">{d.originalIP}</td>
                    <td className="py-1.5">{d.resolvedIP}</td>
                    <td className="py-1.5">
                      {d.spoofedIP ? <span className="text-[var(--cyber-danger)]">SPOOFED</span> : <span className="text-[var(--cyber-success)]">LEGIT</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
