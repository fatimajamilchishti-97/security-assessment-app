'use client';

import { useState } from 'react';
import { GitCompare, Lock, Unlock, Eye, AlertTriangle, ShieldCheck } from 'lucide-react';
import { motion } from 'framer-motion';

interface TrafficExample {
  title: string;
  unprotected: {
    visible: boolean;
    packet: string[];
    risk: string;
    icon: typeof Eye;
  };
  protected: {
    visible: boolean;
    packet: string[];
    safe: string;
    icon: typeof Eye;
  };
  mitigation: string;
}

const COMPARISONS: TrafficExample[] = [
  {
    title: 'Login Credential Transmission',
    unprotected: {
      visible: true,
      packet: [
        'POST /login HTTP/1.1',
        'Host: university.edu',
        'Content-Type: application/x-www-form-urlencoded',
        '',
        'username=jsmith2024&password=Password123!',
      ],
      risk: 'Credentials sent in PLAINTEXT — visible to anyone sniffing the network',
      icon: Eye,
    },
    protected: {
      visible: false,
      packet: [
        'TLS 1.3 Application Data',
        'Encrypted payload: 4a8f2b1c9d3e...',
        'Content: [ENCRYPTED]',
        '',
        '--- Decryption requires session key ---',
      ],
      safe: 'TLS encryption makes payload unreadable without the session key',
      icon: Lock,
    },
    mitigation: 'HTTPS + TLS 1.3',
  },
  {
    title: 'Session Cookie in Transit',
    unprotected: {
      visible: true,
      packet: [
        'GET /dashboard HTTP/1.1',
        'Host: university.edu',
        'Cookie: session=abc123def456ghi789',
        '',
        'Cookie accessible via JavaScript (no HttpOnly)',
        'Cookie sent over HTTP (no Secure flag)',
      ],
      risk: 'Session token exposed — attacker can hijack the session',
      icon: Eye,
    },
    protected: {
      visible: false,
      packet: [
        'TLS 1.3 Application Data',
        'Cookie: [ENCRYPTED]',
        'Flags: HttpOnly=true; Secure=true; SameSite=Strict',
        '',
        'JavaScript: document.cookie → "" (empty)',
      ],
      safe: 'Cookie encrypted in transit AND protected from XSS access',
      icon: Lock,
    },
    mitigation: 'Secure + HttpOnly + SameSite cookies over HTTPS',
  },
  {
    title: 'DNS Query Resolution',
    unprotected: {
      visible: true,
      packet: [
        'DNS Query: facebook.com → A record',
        'Response: facebook.com → 192.168.1.50',
        '',
        'No signature verification',
        'Attacker-controlled IP accepted without validation',
      ],
      risk: 'DNS response can be forged — victim connects to attacker server',
      icon: AlertTriangle,
    },
    protected: {
      visible: true,
      packet: [
        'DNS Query: facebook.com → A record',
        'Response: facebook.com → 157.240.1.35',
        'DNSSEC Signature: RRSIG valid ✓',
        'Chain of trust: . → com → facebook.com ✓',
      ],
      safe: 'Cryptographic signature proves response authenticity',
      icon: ShieldCheck,
    },
    mitigation: 'DNSSEC validation',
  },
  {
    title: 'ARP Table Entry',
    unprotected: {
      visible: true,
      packet: [
        'ARP Table (dynamic):',
        '  192.168.1.1   → AA:BB:CC:DD:EE:FF  (gateway)',
        '  192.168.1.1   → DE:AD:BE:EF:00:01  (OVERWRITTEN)',
        '',
        'Poisoned entry accepted silently',
        'No verification of ARP reply source',
      ],
      risk: 'Gateway MAC overwritten — all traffic routed through attacker',
      icon: AlertTriangle,
    },
    protected: {
      visible: true,
      packet: [
        'ARP Table (static + DAI):',
        '  192.168.1.1   → FF:FF:FF:00:00:01  (STATIC)',
        '',
        'ARP reply from DE:AD:BE:EF:00:01 REJECTED',
        'DAI: Port 5 — MAC mismatch, packet dropped',
      ],
      safe: 'Static entry cannot be overwritten; switch validates ARP',
      icon: ShieldCheck,
    },
    mitigation: 'Static ARP + Dynamic ARP Inspection (DAI)',
  },
];

export default function ComparePage() {
  const [selectedIdx, setSelectedIdx] = useState(0);
  const selected = COMPARISONS[selectedIdx];
  const UnprotectedIcon = selected.unprotected.icon;
  const ProtectedIcon = selected.protected.icon;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-3">
          <GitCompare className="w-6 h-6 text-[var(--cyber-warning)]" />
          Traffic Comparison
        </h1>
        <p className="text-sm text-[var(--cyber-text-dim)]">Side-by-side: unsecured vs secured traffic for each attack vector</p>
      </div>

      <div className="flex gap-2 flex-wrap">
        {COMPARISONS.map((c, i) => (
          <button
            key={i}
            onClick={() => setSelectedIdx(i)}
            className={`cyber-btn text-xs ${selectedIdx === i ? 'cyber-btn-primary' : 'cyber-btn-ghost'}`}
          >
            {c.title}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          key={`unprotected-${selectedIdx}`}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-[var(--cyber-surface)] border-2 border-[var(--cyber-danger)]/40 rounded-lg overflow-hidden"
        >
          <div className="bg-[var(--cyber-danger)]/10 px-4 py-3 flex items-center gap-3 border-b border-[var(--cyber-danger)]/20">
            <UnprotectedIcon className="w-5 h-5 text-[var(--cyber-danger)]" />
            <div>
              <h3 className="text-sm font-medium text-[var(--cyber-danger)]">Unprotected</h3>
              <p className="text-[10px] text-[var(--cyber-text-dim)]">{selected.title}</p>
            </div>
            <Unlock className="w-4 h-4 text-[var(--cyber-danger)] ml-auto" />
          </div>
          <div className="p-4">
            <pre className="bg-[var(--cyber-bg)] rounded-lg p-4 text-xs font-mono overflow-x-auto whitespace-pre-wrap leading-relaxed">
              {selected.unprotected.packet.map((line, i) => (
                <span key={i} className={line.includes('Password') || line.includes('password') || line.includes('session=') || line.includes('OVERWRITTEN') || line.includes('DE:AD:BE:EF') ? 'text-[var(--cyber-danger)] font-bold' : line.includes('PLAINTEXT') || line.includes('visible') || line.includes('no HttpOnly') || line.includes('no Secure') || line.includes('No verification') || line.includes('accepted without') ? 'text-[var(--cyber-warning)]' : 'text-[var(--cyber-text-dim)]'}>
                  {line}
                  {'\n'}
                </span>
              ))}
            </pre>
            <div className="mt-3 bg-[var(--cyber-danger)]/10 border border-[var(--cyber-danger)]/20 rounded-lg p-3 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-[var(--cyber-danger)] flex-shrink-0 mt-0.5" />
              <p className="text-xs text-[var(--cyber-danger)]">{selected.unprotected.risk}</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          key={`protected-${selectedIdx}`}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-[var(--cyber-surface)] border-2 border-[var(--cyber-success)]/40 rounded-lg overflow-hidden"
        >
          <div className="bg-[var(--cyber-success)]/10 px-4 py-3 flex items-center gap-3 border-b border-[var(--cyber-success)]/20">
            <ProtectedIcon className="w-5 h-5 text-[var(--cyber-success)]" />
            <div>
              <h3 className="text-sm font-medium text-[var(--cyber-success)]">Protected</h3>
              <p className="text-[10px] text-[var(--cyber-text-dim)]">{selected.title}</p>
            </div>
            <Lock className="w-4 h-4 text-[var(--cyber-success)] ml-auto" />
          </div>
          <div className="p-4">
            <pre className="bg-[var(--cyber-bg)] rounded-lg p-4 text-xs font-mono overflow-x-auto whitespace-pre-wrap leading-relaxed">
              {selected.protected.packet.map((line, i) => (
                <span key={i} className={line.includes('ENCRYPTED') || line.includes('encrypted') ? 'text-[var(--cyber-primary)]' : line.includes('valid') || line.includes('✓') || line.includes('HttpOnly=true') || line.includes('Secure=true') || line.includes('STATIC') || line.includes('REJECTED') || line.includes('dropped') || line.includes('empty') ? 'text-[var(--cyber-success)]' : 'text-[var(--cyber-text-dim)]'}>
                  {line}
                  {'\n'}
                </span>
              ))}
            </pre>
            <div className="mt-3 bg-[var(--cyber-success)]/10 border border-[var(--cyber-success)]/20 rounded-lg p-3 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-[var(--cyber-success)] flex-shrink-0 mt-0.5" />
              <p className="text-xs text-[var(--cyber-success)]">{selected.protected.safe}</p>
            </div>
          </div>
        </motion.div>
      </div>

      <div className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-4 text-center">
        <span className="text-xs text-[var(--cyber-text-dim)]">Applied Mitigation: </span>
        <span className="text-sm font-medium text-[var(--cyber-primary)]">{selected.mitigation}</span>
      </div>
    </div>
  );
}
