'use client';

import { useState } from 'react';
import { GraduationCap, BookOpen, AlertTriangle, Shield, Globe, Wifi, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface CaseStudy {
  id: string;
  title: string;
  year: string;
  severity: 'critical' | 'high' | 'medium';
  summary: string;
  attack: string;
  impact: string;
  lesson: string;
  mitigation: string;
}

const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'dnschanger',
    title: 'DNSChanger Malware',
    year: '2011',
    severity: 'critical',
    summary: 'A trojan infected 4+ million computers across 100+ countries, changing DNS settings to redirect traffic through attacker-controlled servers. Generated an estimated $14 million in fraudulent ad revenue.',
    attack: 'DNS hijacking via malware that modified system DNS resolver settings. All DNS queries routed to Rove Digital\'s servers in Estonia, which returned spoofed IP addresses for thousands of domains.',
    impact: '4 million+ infected systems. Fraudulent DNS responses served fake ads, intercepted banking sessions, and disabled antivirus updates. FBI operation "Ghost Click" took down the infrastructure but had to maintain replacement DNS servers for months to prevent internet blackout for victims.',
    lesson: 'DNS is a foundational trust layer — compromising it compromises everything built on top. End-users rarely notice DNS changes until services break.',
    mitigation: 'DNSSEC validation, DNS over HTTPS (DoH), DNS monitoring for unexpected resolver changes, endpoint detection of DNS config modifications.',
  },
  {
    id: 'sslstrip',
    title: 'sslstrip by Moxie Marlinspike',
    year: '2009',
    severity: 'high',
    summary: 'Demonstrated that HTTPS protection could be completely bypassed by transparently downgrading connections. Released as a tool at DEFCON 17, proving HSTS was necessary.',
    attack: 'ARP spoof to gain MITM position, then intercept HTTPS connections and proxy them as HTTP. The tool maintained a mapping of HTTPS URLs and transparently converted links. Users never saw a certificate warning.',
    impact: 'Exposed a fundamental flaw in the HTTPS deployment model. Sites without HSTS headers were vulnerable. Led directly to the HSTS specification (RFC 6797) in 2012. Still effective today against sites without proper HSTS preloading.',
    lesson: 'Encryption is only as strong as its enforcement mechanism. The browser\'s address bar padlock gave false confidence when connections could be silently downgraded.',
    mitigation: 'HSTS with long max-age, HSTS preloading, HTTPS-only redirects at the server level, certificate monitoring.',
  },
  {
    id: 'firesheep',
    title: 'FireSheep Firefox Extension',
    year: '2010',
    severity: 'high',
    summary: 'A Firefox extension that automated session hijacking on open WiFi networks. With one click, it captured session cookies from Facebook, Twitter, Flickr, and dozens of other sites.',
    attack: 'Passive packet sniffing on shared WiFi (hub-like or monitor mode). Filtered HTTP traffic for session cookies from a list of known sites. One-click to inject the stolen cookie into the attacker\'s browser session.',
    impact: 'Democratized session hijacking — no technical skill required. Featured in major news outlets. Directly forced Facebook, Twitter, Google, and others to deploy full HTTPS. Accelerated the "HTTPS everywhere" movement.',
    lesson: 'Session cookies transmitted over HTTP are trivially stealable. The problem wasn\'t the users\' fault — it was the sites\' failure to use HTTPS for all pages, not just login.',
    mitigation: 'HTTPS for entire site (not just login), Secure flag on cookies, HttpOnly flag, SameSite attribute.',
  },
  {
    id: 'evil_twin',
    title: 'Evil Twin WiFi Attacks',
    year: 'Ongoing',
    severity: 'critical',
    summary: 'Attacker creates a WiFi access point with the same SSID as a legitimate one (e.g., "Starbucks WiFi"). Devices auto-connect based on saved network profiles, giving the attacker full MITM capability.',
    attack: 'Rogue AP with identical SSID and stronger signal. When victim connects, attacker controls DHCP, DNS, and all traffic routing. Can combine with SSL stripping, DNS spoofing, and credential harvesting simultaneously.',
    impact: 'Extremely common at airports, hotels, conferences, and cafes. Nearly impossible for end-users to detect. Can be combined with captive portal phishing pages for credential harvesting at scale.',
    lesson: 'WiFi client behavior (auto-connect to known SSIDs, prefer stronger signal) creates an exploitable trust assumption. The "free WiFi" model is inherently risky.',
    mitigation: 'VPN on all public WiFi, disable auto-connect to open networks, use WiFi authentication (WPA3-Enterprise), certificate-based network validation.',
  },
  {
    id: 'comcast',
    title: 'ISP Hotspot JavaScript Injection',
    year: '2017',
    severity: 'medium',
    summary: 'Research showed public WiFi hotspots injected JavaScript into unencrypted HTTP pages for authentication popups. This created a MITM condition affecting all HTTP traffic.',
    attack: 'Captive portal detection via HTTP interception. When a device connected, unencrypted HTTP requests were redirected to an authentication page via JavaScript injection. This modified page content in transit.',
    impact: 'Not malicious in intent (authentication), but demonstrated that ANY HTTP modification is possible when you control the network. The injected JS could theoretically be used for tracking, ad injection, or credential theft by a malicious actor.',
    lesson: 'Even "legitimate" network-level modifications are indistinguishable from attacks. HTTP provides no integrity protection — you cannot verify that the page you received is the page the server sent.',
    mitigation: 'HTTPS everywhere (prevents any injection), Subresource Integrity (SRI) for external scripts, Content Security Policy (CSP) headers.',
  },
];

const SEVERITY_COLORS = {
  critical: 'bg-red-500/20 text-red-400 border-red-500/30',
  high: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
};

export default function EducationPage() {
  const [selectedCase, setSelectedCase] = useState<CaseStudy | null>(null);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-3">
          <GraduationCap className="w-6 h-6 text-[var(--cyber-accent)]" />
          Education Center
        </h1>
        <p className="text-sm text-[var(--cyber-text-dim)]">Real-world case studies, attack explanations, and defensive strategies</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {CASE_STUDIES.map((cs, i) => (
          <motion.div
            key={cs.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            onClick={() => setSelectedCase(cs)}
            className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-4 cursor-pointer hover:border-[var(--cyber-primary)]/30 transition-all"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] text-[var(--cyber-text-dim)]">{cs.year}</span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full border ${SEVERITY_COLORS[cs.severity]}`}>
                {cs.severity.toUpperCase()}
              </span>
            </div>
            <h3 className="text-sm font-medium mb-2">{cs.title}</h3>
            <p className="text-xs text-[var(--cyber-text-dim)] line-clamp-3">{cs.summary}</p>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {selectedCase && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-6"
            onClick={() => setSelectedCase(null)}
          >
            <div
              className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-xl max-w-3xl w-full max-h-[80vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6 border-b border-[var(--cyber-border)] flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-lg font-bold">{selectedCase.title}</h2>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full border ${SEVERITY_COLORS[selectedCase.severity]}`}>
                      {selectedCase.severity}
                    </span>
                  </div>
                  <span className="text-xs text-[var(--cyber-text-dim)]">{selectedCase.year}</span>
                </div>
                <button onClick={() => setSelectedCase(null)} className="text-[var(--cyber-text-dim)] hover:text-white text-lg">✕</button>
              </div>
              <div className="p-6 space-y-5">
                <div>
                  <h4 className="text-xs font-medium text-[var(--cyber-text-dim)] uppercase tracking-wider mb-2 flex items-center gap-2">
                    <BookOpen className="w-3 h-3" /> Summary
                  </h4>
                  <p className="text-sm leading-relaxed">{selectedCase.summary}</p>
                </div>
                <div>
                  <h4 className="text-xs font-medium text-[var(--cyber-danger)] uppercase tracking-wider mb-2 flex items-center gap-2">
                    <AlertTriangle className="w-3 h-3" /> Attack Technique
                  </h4>
                  <p className="text-sm leading-relaxed text-[var(--cyber-text-dim)]">{selectedCase.attack}</p>
                </div>
                <div>
                  <h4 className="text-xs font-medium text-[var(--cyber-warning)] uppercase tracking-wider mb-2 flex items-center gap-2">
                    <AlertTriangle className="w-3 h-3" /> Real-World Impact
                  </h4>
                  <p className="text-sm leading-relaxed text-[var(--cyber-text-dim)]">{selectedCase.impact}</p>
                </div>
                <div>
                  <h4 className="text-xs font-medium text-[var(--cyber-accent)] uppercase tracking-wider mb-2 flex items-center gap-2">
                    <GraduationCap className="w-3 h-3" /> Key Lesson
                  </h4>
                  <p className="text-sm leading-relaxed">{selectedCase.lesson}</p>
                </div>
                <div className="bg-[var(--cyber-success)]/10 border border-[var(--cyber-success)]/20 rounded-lg p-4">
                  <h4 className="text-xs font-medium text-[var(--cyber-success)] uppercase tracking-wider mb-2 flex items-center gap-2">
                    <Shield className="w-3 h-3" /> Mitigation
                  </h4>
                  <p className="text-sm leading-relaxed text-[var(--cyber-success)]">{selectedCase.mitigation}</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-6">
        <h3 className="text-sm font-medium mb-4 flex items-center gap-2">
          <Globe className="w-4 h-4 text-[var(--cyber-accent)]" />
          Quick Reference: Public WiFi Safety
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: Shield, title: 'Use a VPN', desc: 'Encrypts ALL traffic before it leaves your device. Even on a compromised network, attackers only see encrypted packets.' },
            { icon: Wifi, title: 'Avoid Open Networks', desc: 'Disable "connect automatically" for open WiFi. Manually verify network names. Use your phone hotspot as an alternative.' },
            { icon: Lock, title: 'Verify HTTPS', desc: 'Check for the padlock icon. Look for "https://" in the URL. Avoid entering credentials on HTTP pages — ever.' },
            { icon: Globe, title: 'Use DNS over HTTPS', desc: 'Configure DoH in your browser (Cloudflare 1.1.1.1 or Google 8.8.8.8). Prevents DNS spoofing on local networks.' },
          ].map((item, i) => (
            <div key={i} className="bg-[var(--cyber-bg)] rounded-lg p-3">
              <item.icon className="w-5 h-5 text-[var(--cyber-primary)] mb-2" />
              <h4 className="text-xs font-medium mb-1">{item.title}</h4>
              <p className="text-[10px] text-[var(--cyber-text-dim)] leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
