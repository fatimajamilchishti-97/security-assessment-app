import type { Metadata } from 'next';
import './globals.css';
import { SocketProvider } from '@/contexts/SocketContext';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';

export const metadata: Metadata = {
  title: 'MITM Framework | Interactive Attack Simulation',
  description: 'Educational Man-in-the-Middle attack framework for cybersecurity research',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[var(--cyber-bg)] text-[var(--cyber-text)] min-h-screen grid-bg scan-line">
        <SocketProvider>
          <div className="flex min-h-screen">
            <Sidebar />
            <div className="flex-1 flex flex-col">
              <Header />
              <main className="flex-1 overflow-auto p-6">
                {children}
              </main>
            </div>
          </div>
        </SocketProvider>
      </body>
    </html>
  );
}
