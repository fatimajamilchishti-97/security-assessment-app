'use client';

import { useSocket } from '@/contexts/SocketContext';
import { useState, useEffect } from 'react';
import { MitigationState } from '@/types';
import { Shield, Lock, Globe, Key, ShieldCheck, CheckCircle, XCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from 'chart.js';
import { Radar } from 'react-chartjs-2';

ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend);

type MitigationToggleKey = Exclude<keyof MitigationState, 'securityScore'>;

interface MitigationConfig {
  key: MitigationToggleKey;
  label: string;
  description: string;
  defendsAgainst: string[];
  icon: typeof Shield;
  color: string;
}

const MITIGATIONS: MitigationConfig[] = [
  {
    key: 'httpsEverywhere',
    label: 'HTTPS Everywhere',
    description: 'Forces all connections to use HTTPS. Browser extensions and server-side redirects ensure plaintext HTTP is never used. Prevents SSL stripping and most passive eavesdropping.',
    defendsAgainst: ['SSL Stripping', 'Packet Sniffing', 'Session Hijacking'],
    icon: Lock,
    color: '#7c3aed',
  },
  {
    key: 'hsts',
    label: 'HSTS (HTTP Strict Transport Security)',
    description: 'Server sends Strict-Transport-Security header telling the browser to ONLY connect over HTTPS for a specified duration. Even if the user types http://, the browser upgrades to https:// before making any request.',
    defendsAgainst: ['SSL Stripping', 'Downgrade Attacks', 'Protocol Manipulation'],
    icon: Shield,
    color: '#06b6d4',
  },
  {
    key: 'certPinning',
    label: 'Certificate Pinning',
    description: 'Application stores a known-good certificate fingerprint (or public key) and validates the server certificate against it during TLS handshake. Prevents acceptance of fraudulent certificates even if a CA is compromised.',
    defendsAgainst: ['Fake Login Pages', 'DNS Spoofing', 'MITM with Fraudulent Certs'],
    icon: Key,
    color: '#f59e0b',
  },
  {
    key: 'arpCacheSecurity',
    label: 'ARP Cache Hardening',
    description: 'Static ARP entries for gateway, ARP inspection on switches (DAI), and ARP rate limiting prevent poisoned entries from being accepted. The gateway MAC-to-IP mapping cannot be overwritten.',
    defendsAgainst: ['ARP Spoofing', 'ARP Poisoning', 'LAN MitM Positioning'],
    icon: ShieldCheck,
    color: '#10b981',
  },
  {
    key: 'vpnActive',
    label: 'VPN Tunnel',
    description: 'All traffic is encrypted in a tunnel before leaving the device. Even on a compromised LAN with an active ARP spoof, the attacker only sees encrypted VPN packets. The inner payload (HTTP, DNS, etc.) is unreadable.',
    defendsAgainst: ['Packet Sniffing', 'SSL Stripping', 'Session Hijacking', 'DNS Spoofing'],
    icon: Lock,
    color: '#ec4899',
  },
  {
    key: 'dnssec',
    label: 'DNSSEC Validation',
    description: 'DNS responses are cryptographically signed by the zone owner. The resolver verifies the signature before accepting the response. Spoofed DNS responses with invalid signatures are rejected.',
    defendsAgainst: ['DNS Spoofing', 'DNS Cache Poisoning', 'Domain Hijacking'],
    icon: Globe,
    color: '#8b5cf6',
  },
];

export default function MitigationPage() {
  const { socket } = useSocket();
  const [state, setState] = useState<MitigationState>({
    httpsEverywhere: false, hsts: false, certPinning: false,
    arpCacheSecurity: false, vpnActive: false, dnssec: false, securityScore: 0,
  });

  useEffect(() => {
    const onMitigation = (s: MitigationState) => setState(s);
    socket.on('mitigation:update', onMitigation);
    return () => { socket.off('mitigation:update', onMitigation); };
  }, [socket]);

  const toggle = (key: MitigationToggleKey) => {
    const newVal = !state[key];
    socket.emit('mitigation:toggle', { key, value: newVal });
    setState((prev) => ({ ...prev, [key]: newVal }));
  };

  const radarData = {
    labels: MITIGATIONS.map((m) => m.label),
    datasets: [
      {
        label: 'Protection Level',
        data: MITIGATIONS.map((m) => (state[m.key] ? 100 : 0)),
        borderColor: '#7c3aed',
        backgroundColor: 'rgba(124, 58, 237, 0.15)',
        pointBackgroundColor: MITIGATIONS.map((m) => (state[m.key] ? m.color : '#1e1e2e')),
        pointBorderColor: MITIGATIONS.map((m) => (state[m.key] ? m.color : '#1e1e2e')),
        pointRadius: 6,
        borderWidth: 2,
      },
    ],
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-3">
          <Shield className="w-6 h-6 text-[var(--cyber-success)]" />
          Mitigation Controls
        </h1>
        <p className="text-sm text-[var(--cyber-text-dim)]">Toggle defenses to see how each countermeasure blocks specific attack vectors</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
          {MITIGATIONS.map((mit, i) => {
            const isActive = state[mit.key];
            const Icon = mit.icon;
            return (
              <motion.div
                key={mit.key}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className={`bg-[var(--cyber-surface)] border rounded-lg p-4 transition-all duration-300
                  ${isActive ? 'border-[var(--cyber-success)]/50' : 'border-[var(--cyber-border)]'}`}
                style={isActive ? { boxShadow: `0 0 15px ${mit.color}22` } : {}}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ background: `${mit.color}15`, color: mit.color }}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">{mit.label}</h3>
                      <span className={`text-[10px] ${isActive ? 'text-[var(--cyber-success)]' : 'text-[var(--cyber-text-dim)]'}`}>
                        {isActive ? 'ACTIVE' : 'DISABLED'}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => toggle(mit.key)}
                    className={`w-12 h-6 rounded-full transition-colors duration-300 relative ${isActive ? '' : 'bg-[var(--cyber-border)]'}`}
                    style={isActive ? { background: mit.color } : {}}
                  >
                    <motion.div
                      className="w-5 h-5 rounded-full bg-white absolute top-0.5"
                      animate={{ left: isActive ? '26px' : '2px' }}
                      transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                    />
                  </button>
                </div>
                <p className="text-[11px] text-[var(--cyber-text-dim)] leading-relaxed mb-3">{mit.description}</p>
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-[var(--cyber-text-dim)]">Defends against:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {mit.defendsAgainst.map((d) => (
                      <span
                        key={d}
                        className={`text-[10px] px-2 py-0.5 rounded-full ${isActive ? 'bg-[var(--cyber-success)]/10 text-[var(--cyber-success)] border border-[var(--cyber-success)]/20' : 'bg-[var(--cyber-bg)] text-[var(--cyber-text-dim)]'}`}
                      >
                        {isActive ? <CheckCircle className="w-2.5 h-2.5 inline mr-0.5" /> : <XCircle className="w-2.5 h-2.5 inline mr-0.5" />}
                        {d}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="space-y-4">
          <div className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-6">
            <h3 className="text-sm font-medium mb-4 text-center">Security Score</h3>
            <div className="flex justify-center mb-4">
              <div className="relative w-40 h-40">
                <svg className="w-40 h-40 -rotate-90" viewBox="0 0 120 120">
                  <circle cx="60" cy="60" r="50" fill="none" stroke="var(--cyber-border)" strokeWidth="8" />
                  <circle
                    cx="60" cy="60" r="50" fill="none"
                    stroke={state.securityScore >= 80 ? 'var(--cyber-success)' : state.securityScore >= 40 ? 'var(--cyber-warning)' : 'var(--cyber-danger)'}
                    strokeWidth="8"
                    strokeDasharray={`${(state.securityScore / 100) * 314} 314`}
                    strokeLinecap="round"
                    style={{ transition: 'stroke-dasharray 0.5s ease, stroke 0.3s ease' }}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl font-bold">{state.securityScore}</span>
                  <span className="text-[10px] text-[var(--cyber-text-dim)]">/ 100</span>
                </div>
              </div>
            </div>
            <div className="space-y-1.5">
              {MITIGATIONS.map((m) => (
                <div key={m.key} className="flex items-center justify-between text-xs">
                  <span className="text-[var(--cyber-text-dim)]">{m.label}</span>
                  <span className={state[m.key] ? 'text-[var(--cyber-success)]' : 'text-[var(--cyber-text-dim)]'}>
                    {state[m.key] ? 'ON' : 'OFF'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-4">
            <h3 className="text-sm font-medium mb-3 text-center">Coverage Radar</h3>
            <div className="h-56">
              <Radar data={radarData} options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                  r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { display: false },
                    grid: { color: 'rgba(255,255,255,0.05)' },
                    pointLabels: { color: '#64748b', font: { size: 9 } },
                    angleLines: { color: 'rgba(255,255,255,0.05)' },
                  },
                },
              }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
