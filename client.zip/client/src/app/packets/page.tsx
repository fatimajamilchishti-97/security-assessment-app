'use client';

import { useSocket } from '@/contexts/SocketContext';
import { useState, useEffect, useRef } from 'react';
import { SimulatedPacket } from '@/types';
import { FileSearch, Pause, Play, Trash2 } from 'lucide-react';

const PROTOCOL_COLORS: Record<string, string> = {
  ARP: 'text-purple-400 bg-purple-500/10',
  DNS: 'text-cyan-400 bg-cyan-500/10',
  TCP: 'text-blue-400 bg-blue-500/10',
  HTTP: 'text-green-400 bg-green-500/10',
  HTTPS: 'text-emerald-400 bg-emerald-500/10',
  TLS: 'text-emerald-400 bg-emerald-500/10',
  ICMP: 'text-yellow-400 bg-yellow-500/10',
};

export default function PacketsPage() {
  const { socket } = useSocket();
  const [packets, setPackets] = useState<SimulatedPacket[]>([]);
  const [selectedPacket, setSelectedPacket] = useState<SimulatedPacket | null>(null);
  const [filter, setFilter] = useState('');
  const [protocolFilter, setProtocolFilter] = useState('ALL');
  const [paused, setPaused] = useState(false);
  const [showModified, setShowModified] = useState(false);
  const tableEndRef = useRef<HTMLDivElement>(null);
  const MAX_PACKETS = 500;

  useEffect(() => {
    const onPacket = (pkt: SimulatedPacket) => {
      if (!paused) {
        setPackets((prev) => [...prev, pkt].slice(-MAX_PACKETS));
      }
    };
    socket.on('packet:captured', onPacket);
    return () => { socket.off('packet:captured', onPacket); };
  }, [socket, paused]);

  useEffect(() => {
    tableEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [packets]);

  const filtered = packets.filter((p) => {
    if (protocolFilter !== 'ALL' && p.protocol !== protocolFilter) return false;
    if (showModified && !p.modified) return false;
    if (filter) {
      const f = filter.toLowerCase();
      return (
        p.sourceIP.includes(f) ||
        p.destIP.includes(f) ||
        p.protocol.toLowerCase().includes(f) ||
        p.info.toLowerCase().includes(f) ||
        p.payload.toLowerCase().includes(f)
      );
    }
    return true;
  });

  const formatHex = (hex: string) => {
    if (!hex) return '';
    return hex.split('\n').map((line, i) => (
      <div key={i} className="hex-font">
        <span className="text-[var(--cyber-text-dim)] mr-3">{(i * 16).toString(16).padStart(8, '0')}</span>
        <span className="text-[var(--cyber-accent)]">{line}</span>
      </div>
    ));
  };

  return (
    <div className="space-y-4 h-[calc(100vh-8rem)] flex flex-col">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-3">
            <FileSearch className="w-6 h-6 text-[var(--cyber-accent)]" />
            Packet Viewer
          </h1>
          <p className="text-sm text-[var(--cyber-text-dim)]">Wireshark-style real-time packet inspection</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-[var(--cyber-text-dim)] mr-2">{filtered.length} packets</span>
          <button
            onClick={() => setPaused(!paused)}
            className={`cyber-btn flex items-center gap-1.5 text-xs ${paused ? 'cyber-btn-primary' : 'cyber-btn-ghost'}`}
          >
            {paused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
            {paused ? 'Resume' : 'Pause'}
          </button>
          <button
            onClick={() => { setPackets([]); setSelectedPacket(null); }}
            className="cyber-btn-ghost flex items-center gap-1.5 text-xs"
          >
            <Trash2 className="w-3 h-3" /> Clear
          </button>
        </div>
      </div>

      <div className="flex gap-3">
        <input
          type="text"
          placeholder="Filter: IP, protocol, keyword..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="cyber-input flex-1 text-xs"
        />
        <select
          value={protocolFilter}
          onChange={(e) => setProtocolFilter(e.target.value)}
          className="cyber-select text-xs w-32"
        >
          <option value="ALL">All Protocols</option>
          <option value="ARP">ARP</option>
          <option value="DNS">DNS</option>
          <option value="TCP">TCP</option>
          <option value="HTTP">HTTP</option>
          <option value="HTTPS">HTTPS</option>
          <option value="TLS">TLS</option>
          <option value="ICMP">ICMP</option>
        </select>
        <button
          onClick={() => setShowModified(!showModified)}
          className={`cyber-btn text-xs ${showModified ? 'cyber-btn-danger' : 'cyber-btn-ghost'}`}
        >
          {showModified ? 'Modified Only' : 'All'}
        </button>
      </div>

      <div className="flex-1 flex gap-4 min-h-0">
        <div className="flex-1 bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg overflow-hidden flex flex-col">
          <div className="overflow-y-auto flex-1">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-[var(--cyber-surface)] z-10">
                <tr className="text-[var(--cyber-text-dim)] text-left border-b border-[var(--cyber-border)]">
                  <th className="px-3 py-2 font-medium w-36">Time</th>
                  <th className="px-3 py-2 font-medium w-16">Proto</th>
                  <th className="px-3 py-2 font-medium">Source</th>
                  <th className="px-3 py-2 font-medium">Destination</th>
                  <th className="px-3 py-2 font-medium">Length</th>
                  <th className="px-3 py-2 font-medium">Info</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((pkt) => (
                  <tr
                    key={pkt.id}
                    onClick={() => setSelectedPacket(pkt)}
                    className={`cursor-pointer border-b border-[var(--cyber-border)]/50 transition-colors
                      ${selectedPacket?.id === pkt.id ? 'bg-[var(--cyber-primary)]/10' : 'hover:bg-[var(--cyber-border)]/30'}
                      ${pkt.modified ? 'border-l-2 border-l-[var(--cyber-danger)]' : ''}`}
                  >
                    <td className="px-3 py-1.5 text-[var(--cyber-text-dim)]">
                      {new Date(pkt.timestamp).toLocaleTimeString('en', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}.{String(pkt.timestamp % 1000).padStart(3, '0')}
                    </td>
                    <td className="px-3 py-1.5">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${PROTOCOL_COLORS[pkt.protocol] || 'text-gray-400 bg-gray-500/10'}`}>
                        {pkt.protocol}
                      </span>
                    </td>
                    <td className="px-3 py-1.5 font-mono">{pkt.sourceIP}{pkt.sourcePort ? `:${pkt.sourcePort}` : ''}</td>
                    <td className="px-3 py-1.5 font-mono">{pkt.destIP}{pkt.destPort ? `:${pkt.destPort}` : ''}</td>
                    <td className="px-3 py-1.5 text-[var(--cyber-text-dim)]">{pkt.size}</td>
                    <td className={`px-3 py-1.5 truncate max-w-xs ${pkt.modified ? 'text-[var(--cyber-danger)]' : ''}`}>
                      {pkt.info}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="text-center py-12 text-[var(--cyber-text-dim)] text-xs">
                {packets.length === 0 ? 'Launch an attack to see packets here' : 'No packets match filter'}
              </div>
            )}
            <div ref={tableEndRef} />
          </div>
        </div>

        {selectedPacket && (
          <div className="w-96 bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg overflow-hidden flex flex-col">
            <div className="p-3 border-b border-[var(--cyber-border)] flex items-center justify-between">
              <span className="text-xs font-medium">Packet Detail</span>
              <button onClick={() => setSelectedPacket(null)} className="text-[var(--cyber-text-dim)] hover:text-white text-xs">✕</button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-4">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">Frame</span>
                  <span className="font-mono">{selectedPacket.id.substring(0, 8)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">Arrival</span>
                  <span className="font-mono">{new Date(selectedPacket.timestamp).toLocaleTimeString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">Protocol</span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${PROTOCOL_COLORS[selectedPacket.protocol] || ''}`}>
                    {selectedPacket.protocol}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">Size</span>
                  <span className="font-mono">{selectedPacket.size} bytes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">Modified</span>
                  <span className={selectedPacket.modified ? 'text-[var(--cyber-danger)]' : 'text-[var(--cyber-success)]'}>
                    {selectedPacket.modified ? 'YES' : 'NO'}
                  </span>
                </div>
              </div>

              <div>
                <h4 className="text-[10px] uppercase tracking-wider text-[var(--cyber-text-dim)] mb-2">Ethernet</h4>
                <div className="space-y-1 text-xs bg-[var(--cyber-bg)] rounded p-2">
                  <div className="flex justify-between">
                    <span className="text-[var(--cyber-text-dim)]">Src MAC</span>
                    <span className="font-mono text-[10px]">{selectedPacket.sourceMAC}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[var(--cyber-text-dim)]">Dst MAC</span>
                    <span className="font-mono text-[10px]">{selectedPacket.destMAC}</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-[10px] uppercase tracking-wider text-[var(--cyber-text-dim)] mb-2">Network</h4>
                <div className="space-y-1 text-xs bg-[var(--cyber-bg)] rounded p-2">
                  <div className="flex justify-between">
                    <span className="text-[var(--cyber-text-dim)]">Src IP</span>
                    <span className="font-mono">{selectedPacket.sourceIP}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[var(--cyber-text-dim)]">Dst IP</span>
                    <span className="font-mono">{selectedPacket.destIP}</span>
                  </div>
                  {selectedPacket.sourcePort && (
                    <div className="flex justify-between">
                      <span className="text-[var(--cyber-text-dim)]">Src Port</span>
                      <span className="font-mono">{selectedPacket.sourcePort}</span>
                    </div>
                  )}
                  {selectedPacket.destPort && (
                    <div className="flex justify-between">
                      <span className="text-[var(--cyber-text-dim)]">Dst Port</span>
                      <span className="font-mono">{selectedPacket.destPort}</span>
                    </div>
                  )}
                </div>
              </div>

              {selectedPacket.raw.length > 0 && (
                <div>
                  <h4 className="text-[10px] uppercase tracking-wider text-[var(--cyber-text-dim)] mb-2">Decoded</h4>
                  <div className="bg-[var(--cyber-bg)] rounded p-2 text-xs space-y-0.5">
                    {selectedPacket.raw.map((line, i) => (
                      <div key={i} className={line.includes('SPOOFED') || line.includes('HIJACKED') || line.includes('INTERCEPTED') || line.includes('EXPOSED') || line.includes('CAPTURED') || line.includes('DOWNGRADED') || line.includes('STRIPPED') || line.includes('EXFIL') ? 'text-[var(--cyber-danger)]' : line.includes('[TLS') ? 'text-[var(--cyber-success)]' : 'text-[var(--cyber-text-dim)]'}>
                        {line}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <h4 className="text-[10px] uppercase tracking-wider text-[var(--cyber-text-dim)] mb-2">Hex Dump</h4>
                <div className="bg-[var(--cyber-bg)] rounded p-2 overflow-x-auto max-h-48 overflow-y-auto">
                  {formatHex(selectedPacket.hexDump)}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
