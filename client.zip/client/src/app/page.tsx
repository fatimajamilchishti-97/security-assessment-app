'use client';

import { useSocket } from '@/contexts/SocketContext';
import { useState, useEffect, useRef } from 'react';
import { DashboardStats, LogEntry, AttackState, ATTACK_LABELS } from '@/types';
import {
  Activity,
  Zap,
  Shield,
  UserX,
  FileText,
  Wifi,
  Square,
  RotateCcw,
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Filler,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Filler, Tooltip, Legend);

export default function DashboardPage() {
  const { socket } = useSocket();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [activeAttacks, setActiveAttacks] = useState<AttackState[]>([]);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onStats = (s: DashboardStats) => setStats(s);
    const onLog = (l: LogEntry) => setLogs((prev) => [...prev.slice(-100), l]);
    const onLaunched = (a: AttackState) => setActiveAttacks((prev) => [...prev, a]);
    const onStopped = (id: string) => setActiveAttacks((prev) => prev.filter((a) => a.id !== id));
    const onMitigated = (id: string) => setActiveAttacks((prev) => prev.filter((a) => a.id !== id));
    socket.on('stats:update', onStats);
    socket.on('log:message', onLog);
    socket.on('attack:launched', onLaunched);
    socket.on('attack:stopped', onStopped);
    socket.on('attack:mitigated', onMitigated);
    return () => {
      socket.off('stats:update', onStats);
      socket.off('log:message', onLog);
      socket.off('attack:launched', onLaunched);
      socket.off('attack:stopped', onStopped);
      socket.off('attack:mitigated', onMitigated);
    };
  }, [socket]);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const statCards = stats
    ? [
        { label: 'Total Packets', value: stats.totalPackets.toLocaleString(), icon: FileText, color: 'text-[var(--cyber-accent)]' },
        { label: 'Captured', value: stats.capturedPackets.toLocaleString(), icon: Activity, color: 'text-[var(--cyber-primary)]' },
        { label: 'Modified', value: stats.modifiedPackets.toLocaleString(), icon: Zap, color: 'text-[var(--cyber-warning)]' },
        { label: 'Active Attacks', value: stats.activeAttacks.toString(), icon: Wifi, color: 'text-[var(--cyber-danger)]' },
        { label: 'Compromised', value: stats.compromisedDevices.toString(), icon: UserX, color: 'text-[var(--cyber-danger)]' },
        { label: 'Credentials', value: stats.credentialsCaptured.toString(), icon: Shield, color: 'text-[var(--cyber-warning)]' },
      ]
    : [];

  const timelineData = {
    labels: stats?.attackTimeline.map((t) => t.time) || [],
    datasets: [
      {
        label: 'Packets',
        data: stats?.attackTimeline.map((t) => t.count) || [],
        borderColor: '#7c3aed',
        backgroundColor: 'rgba(124, 58, 237, 0.1)',
        fill: true,
        tension: 0.4,
        pointRadius: 0,
        borderWidth: 2,
      },
    ],
  };

  const logColor = (level: LogEntry['level']) => {
    switch (level) {
      case 'attack': return 'text-[var(--cyber-danger)]';
      case 'warn': return 'text-[var(--cyber-warning)]';
      case 'error': return 'text-[var(--cyber-danger)]';
      case 'success': return 'text-[var(--cyber-success)]';
      default: return 'text-[var(--cyber-text-dim)]';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Command Dashboard</h1>
          <p className="text-sm text-[var(--cyber-text-dim)]">Real-time attack monitoring and simulation control</p>
        </div>
        <button
          onClick={() => socket.emit('attack:stopAll')}
          className="cyber-btn-danger flex items-center gap-2"
        >
          <RotateCcw className="w-3 h-3" /> Stop All
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {statCards.map((card) => (
          <div key={card.label} className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-4 hover:border-[var(--cyber-primary)]/30 transition-colors">
            <div className={`flex items-center gap-2 mb-2 ${card.color}`}>
              <card.icon className="w-4 h-4" />
              <span className="text-[10px] uppercase tracking-wider text-[var(--cyber-text-dim)]">{card.label}</span>
            </div>
            <p className="text-xl font-bold">{card.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-4">
          <h3 className="text-sm font-medium mb-4">Packet Capture Timeline</h3>
          <div className="h-48">
            <Line data={timelineData} options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: { legend: { display: false } },
              scales: {
                x: { grid: { color: 'rgba(255,255,255,0.03)' }, ticks: { color: '#64748b', font: { size: 10 } } },
                y: { grid: { color: 'rgba(255,255,255,0.03)' }, ticks: { color: '#64748b', font: { size: 10 } } },
              },
            }} />
          </div>
        </div>

        <div className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-4">
          <h3 className="text-sm font-medium mb-4">Active Attacks</h3>
          {activeAttacks.length === 0 ? (
            <p className="text-[var(--cyber-text-dim)] text-xs text-center py-8">No active attacks</p>
          ) : (
            <div className="space-y-2">
              {activeAttacks.map((a) => (
                <div key={a.id} className="flex items-center justify-between p-2 rounded bg-[var(--cyber-bg)] border border-[var(--cyber-danger)]/30 attack-active">
                  <div>
                    <p className="text-xs font-medium">{ATTACK_LABELS[a.type]}</p>
                    <p className="text-[10px] text-[var(--cyber-text-dim)]">{a.packetsGenerated} pkts</p>
                  </div>
                  <button
                    onClick={() => socket.emit('attack:stop', a.id)}
                    className="p-1 rounded hover:bg-[var(--cyber-danger)]/20 transition-colors"
                  >
                    <Square className="w-3 h-3 text-[var(--cyber-danger)]" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg">
        <div className="p-4 border-b border-[var(--cyber-border)]">
          <h3 className="text-sm font-medium">Live System Log</h3>
        </div>
        <div className="h-64 overflow-y-auto p-4 terminal-text">
          {logs.map((log, i) => (
            <div key={i} className={`py-0.5 ${logColor(log.level)}`}>
              <span className="text-[var(--cyber-text-dim)]">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
              {log.module && <span className="text-[var(--cyber-accent)]"> [{log.module}]</span>}
              {' '}{log.message}
            </div>
          ))}
          {logs.length === 0 && <p className="text-[var(--cyber-text-dim)] text-center py-8">Waiting for events...</p>}
          <div ref={logEndRef} />
        </div>
      </div>
    </div>
  );
}
