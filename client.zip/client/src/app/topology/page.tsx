'use client';

import { useSocket } from '@/contexts/SocketContext';
import { useState, useEffect, useRef, useCallback } from 'react';
import { VictimDevice, ConnectionInfo } from '@/types';
import { Network, Monitor, Smartphone, Tablet, Printer, Server, Shield, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface NodePosition {
  id: string;
  x: number;
  y: number;
  device?: VictimDevice;
  type: 'victim' | 'gateway' | 'attacker';
}

const DEVICE_ICONS: Record<string, typeof Monitor> = {
  laptop: Monitor,
  phone: Smartphone,
  tablet: Tablet,
  iot: Printer,
  desktop: Monitor,
};

const STATUS_GLOW: Record<string, string> = {
  idle: '',
  active: '0 0 15px rgba(6, 182, 212, 0.5)',
  compromised: '0 0 15px rgba(239, 68, 68, 0.6)',
  protected: '0 0 15px rgba(16, 185, 129, 0.5)',
};

const STATUS_BORDER: Record<string, string> = {
  idle: 'var(--cyber-border)',
  active: 'var(--cyber-accent)',
  compromised: 'var(--cyber-danger)',
  protected: 'var(--cyber-success)',
};

export default function TopologyPage() {
  const { socket } = useSocket();
  const canvasRef = useRef<HTMLDivElement>(null);
  const [nodes, setNodes] = useState<NodePosition[]>([]);
  const [connections, setConnections] = useState<ConnectionInfo[]>([]);
  const [selectedNode, setSelectedNode] = useState<NodePosition | null>(null);
  const [animPulses, setAnimPulses] = useState<{ fromId: string; toId: string; id: number }[]>([]);
  const pulseIdRef = useRef(0);

  useEffect(() => {
    const onTopology = (data: { devices: VictimDevice[]; connections: ConnectionInfo[] }) => {
      const cx = 400;
      const cy = 250;
      const radius = 180;
      const gatewayNode: NodePosition = { id: 'gateway', x: cx, y: cy, type: 'gateway' };
      const attackerNode: NodePosition = { id: 'attacker', x: cx + 120, y: cy + 140, type: 'attacker' };
      const victimNodes = data.devices.map((d, i) => {
        const angle = (2 * Math.PI * i) / data.devices.length - Math.PI / 2;
        return {
          id: d.id,
          x: cx + radius * Math.cos(angle),
          y: cy + radius * Math.sin(angle),
          device: d,
          type: 'victim' as const,
        };
      });
      setNodes([gatewayNode, attackerNode, ...victimNodes]);
      setConnections(data.connections);
      setSelectedNode((prev) => {
        if (!prev || !prev.device) return prev;
        const updated = data.devices.find((d) => d.id === prev.id);
        return updated ? { ...prev, device: updated } : prev;
      });
    };
    socket.on('topology:update', onTopology);
    socket.emit('topology:request');
    return () => { socket.off('topology:update', onTopology); };
  }, [socket]);

  useEffect(() => {
    const interval = setInterval(() => {
      const intercepted = connections.filter((c) => c.type === 'intercepted');
      if (intercepted.length > 0) {
        const conn = intercepted[Math.floor(Math.random() * intercepted.length)];
        const id = pulseIdRef.current++;
        setAnimPulses((prev) => [...prev.slice(-20), { fromId: conn.from, toId: conn.to, id }]);
        setTimeout(() => {
          setAnimPulses((prev) => prev.filter((p) => p.id !== id));
        }, 1500);
      }
    }, 600);
    return () => clearInterval(interval);
  }, [connections]);

  const getNodeById = useCallback((id: string) => nodes.find((n) => n.id === id), [nodes]);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-3">
          <Network className="w-6 h-6 text-[var(--cyber-primary)]" />
          Network Topology
        </h1>
        <p className="text-sm text-[var(--cyber-text-dim)]">Interactive network map — attack paths shown in real-time</p>
      </div>

      <div className="flex gap-6">
        <div
          ref={canvasRef}
          className="flex-1 bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg relative overflow-hidden"
          style={{ height: '550px' }}
        >
          <svg className="absolute inset-0 w-full h-full" style={{ zIndex: 1 }}>
            <defs>
              <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#7c3aed" stopOpacity="0.6" />
                <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.6" />
              </linearGradient>
              <linearGradient id="attackLineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ef4444" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#ef4444" stopOpacity="0.3" />
              </linearGradient>
              <radialGradient id="pulseGrad">
                <stop offset="0%" stopColor="#ef4444" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#ef4444" stopOpacity="0" />
              </radialGradient>
            </defs>

            {connections.map((conn, i) => {
              const from = getNodeById(conn.from);
              const to = getNodeById(conn.to);
              if (!from || !to) return null;
              const isAttacked = conn.type === 'intercepted';
              return (
                <g key={i}>
                  <line
                    x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                    stroke={isAttacked ? 'url(#attackLineGrad)' : 'url(#lineGrad)'}
                    strokeWidth={isAttacked ? 2 : 1}
                    strokeDasharray={isAttacked ? '6,4' : 'none'}
                  />
                  {isAttacked && (
                    <line
                      x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                      stroke="#ef4444"
                      strokeWidth={1}
                      strokeDasharray="6,4"
                      opacity={0.3}
                    >
                      <animate attributeName="stroke-dashoffset" from="0" to="-20" dur="1s" repeatCount="indefinite" />
                    </line>
                  )}
                </g>
              );
            })}

            <AnimatePresence>
              {animPulses.map((pulse) => {
                const from = getNodeById(pulse.fromId);
                const to = getNodeById(pulse.toId);
                if (!from || !to) return null;
                return (
                  <motion.circle
                    key={pulse.id}
                    cx={from.x}
                    cy={from.y}
                    r={3}
                    fill="#ef4444"
                    initial={{ opacity: 1 }}
                    animate={{
                      cx: to.x,
                      cy: to.y,
                      opacity: [1, 0.8, 0],
                      r: [3, 5, 8],
                    }}
                    transition={{ duration: 1.5, ease: 'linear' }}
                  />
                );
              })}
            </AnimatePresence>
          </svg>

          <div className="absolute inset-0" style={{ zIndex: 2 }}>
            {nodes.map((node) => {
              const status = node.device?.status || 'idle';
              const Icon = node.type === 'gateway' ? Server : node.type === 'attacker' ? Shield : (node.device ? DEVICE_ICONS[node.device.type] || Monitor : Monitor);
              const isAttacker = node.type === 'attacker';
              return (
                <motion.div
                  key={node.id}
                  className="absolute flex flex-col items-center cursor-pointer"
                  style={{ left: node.x - 32, top: node.y - 32, width: 64 }}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: node.type === 'gateway' ? 0 : node.type === 'attacker' ? 0.1 : 0.2, type: 'spring' }}
                  onClick={() => setSelectedNode(node)}
                >
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center border-2 transition-all duration-300"
                    style={{
                      borderColor: isAttacker ? 'var(--cyber-danger)' : STATUS_BORDER[status],
                      boxShadow: isAttacker ? '0 0 20px rgba(239, 68, 68, 0.4)' : STATUS_GLOW[status],
                      background: isAttacker ? 'rgba(239, 68, 68, 0.1)' : status === 'compromised' ? 'rgba(239, 68, 68, 0.1)' : 'var(--cyber-surface)',
                    }}
                  >
                    <Icon className={`w-6 h-6 ${isAttacker ? 'text-[var(--cyber-danger)]' : status === 'compromised' ? 'text-[var(--cyber-danger)]' : status === 'protected' ? 'text-[var(--cyber-success)]' : 'text-[var(--cyber-text-dim)]'}`} />
                  </div>
                  <span className="text-[9px] mt-1 text-center text-[var(--cyber-text-dim)] max-w-[80px] truncate">
                    {node.type === 'gateway' ? 'Gateway' : node.type === 'attacker' ? 'Attacker' : node.device?.hostname}
                  </span>
                  {node.device && (
                    <span className="text-[8px] font-mono text-[var(--cyber-text-dim)]">{node.device.ip}</span>
                  )}
                </motion.div>
              );
            })}
          </div>

          <div className="absolute bottom-4 left-4 flex gap-4 text-[10px] text-[var(--cyber-text-dim)]" style={{ zIndex: 3 }}>
            <div className="flex items-center gap-1.5"><div className="w-3 h-0.5 bg-[var(--cyber-primary)]" /> Normal</div>
            <div className="flex items-center gap-1.5"><div className="w-3 h-0.5 bg-[var(--cyber-danger)]" style={{ borderStyle: 'dashed' }} /> Intercepted</div>
            <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-[var(--cyber-danger)]" /> Pulse = Data theft</div>
          </div>
        </div>

        {selectedNode && (
          <div className="w-72 bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg p-4 h-fit">
            <h3 className="text-sm font-medium mb-3">
              {selectedNode.type === 'gateway' ? 'Gateway Router' : selectedNode.type === 'attacker' ? 'Attacker Machine' : selectedNode.device?.hostname}
            </h3>
            {selectedNode.device && (
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">IP</span>
                  <span className="font-mono">{selectedNode.device.ip}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">MAC</span>
                  <span className="font-mono text-[10px]">{selectedNode.device.mac}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">OS</span>
                  <span>{selectedNode.device.os}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">Status</span>
                  <span className={
                    selectedNode.device.status === 'compromised' ? 'text-[var(--cyber-danger)]' :
                    selectedNode.device.status === 'protected' ? 'text-[var(--cyber-success)]' :
                    'text-[var(--cyber-text-dim)]'
                  }>
                    {selectedNode.device.status.toUpperCase()}
                  </span>
                </div>
                <div>
                  <span className="text-[var(--cyber-text-dim)]">Open Ports</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedNode.device.openPorts.map((p) => (
                      <span key={p} className="px-1.5 py-0.5 bg-[var(--cyber-bg)] rounded text-[10px] font-mono">{p}</span>
                    ))}
                  </div>
                </div>
                <div className="bg-[var(--cyber-danger)]/10 border border-[var(--cyber-danger)]/20 rounded p-2 mt-2">
                  <div className="flex items-start gap-1.5">
                    <AlertTriangle className="w-3 h-3 text-[var(--cyber-danger)] flex-shrink-0 mt-0.5" />
                    <span className="text-[var(--cyber-danger)] text-[10px]">{selectedNode.device.vulnerability}</span>
                  </div>
                </div>
              </div>
            )}
            {selectedNode.type === 'attacker' && (
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">IP</span>
                  <span className="font-mono text-[var(--cyber-danger)]">192.168.1.50</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">OS</span>
                  <span>Kali Linux 2024.1</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">Tools</span>
                  <span>mitmproxy, scapy, bettercap</span>
                </div>
                <div className="bg-[var(--cyber-danger)]/10 border border-[var(--cyber-danger)]/20 rounded p-2 mt-2 text-[10px] text-[var(--cyber-danger)]">
                  Simulation attacker — no real tools are running
                </div>
              </div>
            )}
            {selectedNode.type === 'gateway' && (
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">IP</span>
                  <span className="font-mono">192.168.1.1</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">Type</span>
                  <span>LAN Gateway / Router</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--cyber-text-dim)]">Role</span>
                  <span>Default route for all devices</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
