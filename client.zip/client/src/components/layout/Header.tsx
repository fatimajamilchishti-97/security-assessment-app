'use client';

import { useSocket } from '@/contexts/SocketContext';
import { useState, useEffect } from 'react';
import { LogEntry } from '@/types';
import { Bell, Terminal } from 'lucide-react';

export function Header() {
  const { socket } = useSocket();
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [showLog, setShowLog] = useState(false);
  const [alertCount, setAlertCount] = useState(0);

  useEffect(() => {
    const onLog = (log: LogEntry) => {
      setLogs((prev) => [log, ...prev].slice(0, 200));
      if (log.level === 'attack' || log.level === 'warn') {
        setAlertCount((c) => c + 1);
      }
    };
    socket.on('log:message', onLog);
    return () => { socket.off('log:message', onLog); };
  }, [socket]);

  const logColor = (level: LogEntry['level']) => {
    switch (level) {
      case 'attack': return 'text-[var(--cyber-danger)]';
      case 'warn': return 'text-[var(--cyber-warning)]';
      case 'error': return 'text-[var(--cyber-danger)]';
      case 'success': return 'text-[var(--cyber-success)]';
      default: return 'text-[var(--cyber-text-dim)]';
    }
  };

  return (
    <header className="h-14 bg-[var(--cyber-surface)] border-b border-[var(--cyber-border)] flex items-center justify-between px-6 relative">
      <div className="flex items-center gap-4">
        <Terminal className="w-4 h-4 text-[var(--cyber-primary)]" />
        <span className="text-xs text-[var(--cyber-text-dim)]">
          Interactive MITM Attack Framework — Educational Simulation
        </span>
      </div>

      <div className="flex items-center gap-4">
        <button
          onClick={() => { setShowLog(!showLog); setAlertCount(0); }}
          className="relative p-2 rounded-lg hover:bg-[var(--cyber-border)]/50 transition-colors"
        >
          <Bell className="w-4 h-4 text-[var(--cyber-text-dim)]" />
          {alertCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-[var(--cyber-danger)] rounded-full text-[9px] flex items-center justify-center text-white">
              {alertCount > 9 ? '9+' : alertCount}
            </span>
          )}
        </button>

        {showLog && (
          <div className="absolute top-14 right-6 w-96 max-h-80 bg-[var(--cyber-surface)] border border-[var(--cyber-border)] rounded-lg shadow-2xl overflow-hidden z-50">
            <div className="p-3 border-b border-[var(--cyber-border)] flex items-center justify-between">
              <span className="text-xs font-medium">System Log</span>
              <button onClick={() => setShowLog(false)} className="text-[var(--cyber-text-dim)] hover:text-white text-xs">✕</button>
            </div>
            <div className="overflow-y-auto max-h-64 p-2 terminal-text">
              {logs.map((log, i) => (
                <div key={i} className={`py-0.5 ${logColor(log.level)}`}>
                  <span className="text-[var(--cyber-text-dim)]">
                    [{new Date(log.timestamp).toLocaleTimeString()}]
                  </span>
                  {log.module && <span className="text-[var(--cyber-accent)]"> [{log.module}]</span>}
                  {' '}{log.message}
                </div>
              ))}
              {logs.length === 0 && <p className="text-[var(--cyber-text-dim)] text-center py-4">No logs yet</p>}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
