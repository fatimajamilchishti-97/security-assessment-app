'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSocket } from '@/contexts/SocketContext';
import {
  LayoutDashboard,
  Crosshair,
  FileSearch,
  Network,
  Shield,
  GitCompare,
  GraduationCap,
  Activity,
} from 'lucide-react';

const NAV_ITEMS = [
  { href: '/', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/attacks', label: 'Attack Center', icon: Crosshair },
  { href: '/packets', label: 'Packet Viewer', icon: FileSearch },
  { href: '/topology', label: 'Network Topology', icon: Network },
  { href: '/mitigation', label: 'Mitigations', icon: Shield },
  { href: '/compare', label: 'Compare Traffic', icon: GitCompare },
  { href: '/education', label: 'Education', icon: GraduationCap },
];

export function Sidebar() {
  const pathname = usePathname();
  const { connected } = useSocket();

  return (
    <aside className="w-64 bg-[var(--cyber-surface)] border-r border-[var(--cyber-border)] flex flex-col">
      <div className="p-4 border-b border-[var(--cyber-border)]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[var(--cyber-primary)] flex items-center justify-center">
            <Activity className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-wide">MITM FRAMEWORK</h1>
            <p className="text-[10px] text-[var(--cyber-text-dim)] tracking-widest">SIMULATION v1.0</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-3 space-y-1">
        {NAV_ITEMS.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200
                ${isActive
                  ? 'bg-[var(--cyber-primary)]/10 text-[var(--cyber-primary)] border border-[var(--cyber-primary)]/30'
                  : 'text-[var(--cyber-text-dim)] hover:text-[var(--cyber-text)] hover:bg-[var(--cyber-border)]/50'
                }`}
            >
              <Icon className="w-4 h-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-[var(--cyber-border)]">
        <div className="flex items-center gap-2 text-xs">
          <div className={`w-2 h-2 rounded-full ${connected ? 'bg-[var(--cyber-success)]' : 'bg-[var(--cyber-danger)]'}`}
               style={connected ? { boxShadow: '0 0 8px var(--cyber-success)' } : {}} />
          <span className="text-[var(--cyber-text-dim)]">
            {connected ? 'Connected to server' : 'Disconnected'}
          </span>
        </div>
        <p className="text-[10px] text-[var(--cyber-text-dim)] mt-2 opacity-60">
          Simulation only — no real network traffic
        </p>
      </div>
    </aside>
  );
}
