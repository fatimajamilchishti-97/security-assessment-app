export interface SimulatedPacket {
  id: string;
  timestamp: number;
  sourceIP: string;
  sourceMAC: string;
  destIP: string;
  destMAC: string;
  protocol: string;
  sourcePort?: number;
  destPort?: number;
  size: number;
  payload: string;
  hexDump: string;
  info: string;
  modified: boolean;
  captured: boolean;
  raw: string[];
}

export interface VictimDevice {
  id: string;
  hostname: string;
  ip: string;
  mac: string;
  os: string;
  type: 'laptop' | 'phone' | 'tablet' | 'desktop' | 'iot';
  status: 'idle' | 'active' | 'compromised' | 'protected';
  openPorts: number[];
  vulnerability: string;
  trafficRate: number;
}

export interface AttackState {
  id: string;
  type: AttackType;
  status: 'idle' | 'running' | 'stopped' | 'mitigated';
  targetId: string;
  startTime: number;
  packetsGenerated: number;
  dataCaptured: CapturedData;
  config: AttackConfig;
}

export type AttackType =
  | 'arp_spoof'
  | 'dns_spoof'
  | 'ssl_strip'
  | 'session_hijack'
  | 'packet_sniff'
  | 'fake_login'
  | 'cookie_steal';

export interface AttackConfig {
  aggressiveness: 'low' | 'medium' | 'high';
  duration: number;
  autoStop: boolean;
  stealth: boolean;
}

export interface CapturedData {
  credentials: CredentialEntry[];
  cookies: CookieEntry[];
  sessions: SessionEntry[];
  dnsQueries: DNSQueryEntry[];
  modifiedPackets: number;
  injectedContent: string[];
}

export interface CredentialEntry {
  id: string;
  timestamp: number;
  source: string;
  url: string;
  username: string;
  password: string;
  method: string;
}

export interface CookieEntry {
  id: string;
  timestamp: number;
  domain: string;
  name: string;
  value: string;
  httpOnly: boolean;
  secure: boolean;
  path: string;
}

export interface SessionEntry {
  id: string;
  timestamp: number;
  domain: string;
  sessionId: string;
  userId?: string;
  expiry: number;
}

export interface DNSQueryEntry {
  id: string;
  timestamp: number;
  query: string;
  originalIP: string;
  spoofedIP: boolean;
  resolvedIP: string;
  type: string;
}

export interface MitigationState {
  httpsEverywhere: boolean;
  hsts: boolean;
  certPinning: boolean;
  arpCacheSecurity: boolean;
  vpnActive: boolean;
  dnssec: boolean;
  securityScore: number;
}

export interface ConnectionInfo {
  from: string;
  to: string;
  type: 'normal' | 'intercepted' | 'blocked';
  bandwidth: number;
  packetCount: number;
}

export interface LogEntry {
  timestamp: number;
  level: 'info' | 'warn' | 'error' | 'success' | 'attack';
  message: string;
  module?: string;
}

export interface DashboardStats {
  totalPackets: number;
  capturedPackets: number;
  modifiedPackets: number;
  activeAttacks: number;
  compromisedDevices: number;
  credentialsCaptured: number;
  packetsPerSecond: number;
  attackTimeline: { time: string; count: number }[];
}

export const ATTACK_LABELS: Record<AttackType, string> = {
  arp_spoof: 'ARP Spoofing',
  dns_spoof: 'DNS Spoofing',
  ssl_strip: 'SSL Stripping',
  session_hijack: 'Session Hijacking',
  packet_sniff: 'Packet Sniffing',
  fake_login: 'Fake Login Page',
  cookie_steal: 'Cookie Stealing',
};

export const ATTACK_DESCRIPTIONS: Record<AttackType, string> = {
  arp_spoof: 'Poisons ARP cache to intercept traffic between victim and gateway',
  dns_spoof: 'Redirects DNS queries to attacker-controlled IP addresses',
  ssl_strip: 'Downgrades HTTPS connections to HTTP, exposing plaintext data',
  session_hijack: 'Steals session tokens from unencrypted traffic to impersonate users',
  packet_sniff: 'Passively captures all network traffic on the segment',
  fake_login: 'Serves cloned login pages to harvest credentials',
  cookie_steal: 'Uses XSS to exfiltrate cookies from vulnerable applications',
};

export const ATTACK_SEVERITY: Record<AttackType, 'critical' | 'high' | 'medium' | 'low'> = {
  arp_spoof: 'high',
  dns_spoof: 'high',
  ssl_strip: 'critical',
  session_hijack: 'critical',
  packet_sniff: 'medium',
  fake_login: 'critical',
  cookie_steal: 'high',
};
