import { Server } from 'socket.io';
import { v4 as uuid } from 'uuid';
import { AttackState, AttackConfig, VictimDevice, SimulatedPacket, LogEntry } from '../types';
import { generateARPPacket, generateTCPPacket, generateICMPPacket } from '../simulation/packetGenerator';
import { GATEWAY } from '../simulation/victimProfiles';

export class ARPSpoofingAttack {
  private io: Server;
  private attack: AttackState | null = null;
  private intervalIds: NodeJS.Timeout[] = [];
  private victim: VictimDevice | null = null;

  constructor(io: Server) {
    this.io = io;
  }

  launch(victim: VictimDevice, config: AttackConfig): AttackState {
    this.victim = victim;
    this.attack = {
      id: uuid(),
      type: 'arp_spoof',
      status: 'running',
      targetId: victim.id,
      startTime: Date.now(),
      packetsGenerated: 0,
      dataCaptured: {
        credentials: [],
        cookies: [],
        sessions: [],
        dnsQueries: [],
        modifiedPackets: 0,
        injectedContent: [],
      },
      config,
    };

    this.log('info', `ARP Spoofing attack launched against ${victim.hostname} (${victim.ip})`);
    this.log('attack', `Sending poisoned ARP replies: ${victim.ip} -> ${GATEWAY.ip} is at attacker MAC`);
    this.log('warn', `Victim ${victim.hostname} now routes traffic through attacker`);

    this.io.emit('attack:launched', this.attack);
    this.io.emit('victim:status', { ...victim, status: 'compromised' });

    const speed = config.aggressiveness === 'high' ? 500 : config.aggressiveness === 'medium' ? 1200 : 2500;

    const poisonInterval = setInterval(() => {
      if (!this.attack || this.attack.status !== 'running') return;

      const poisonToVictim = generateARPPacket(victim, true, GATEWAY.ip);
      const poisonToGateway = generateARPPacket(
        { ...victim, ip: GATEWAY.ip, mac: GATEWAY.mac },
        true,
        victim.ip
      );

      this.io.emit('packet:captured', poisonToVictim);
      this.io.emit('packet:captured', poisonToGateway);

      if (this.attack) {
        this.attack.packetsGenerated += 2;
        this.attack.dataCaptured.modifiedPackets += 2;
      }
    }, speed);

    this.intervalIds.push(poisonInterval);

    const trafficInterval = setInterval(() => {
      if (!this.attack || this.attack.status !== 'running' || !this.victim) return;

      const rand = Math.random();
      let packet: SimulatedPacket;

      if (rand < 0.6) {
        packet = generateTCPPacket(
          this.victim.ip,
          '142.250.80.46',
          this.victim.mac,
          GATEWAY.mac,
          ['SYN', 'ACK', 'PSH,ACK', 'FIN,ACK'][Math.floor(Math.random() * 4)],
          40 + Math.floor(Math.random() * 1400)
        );
        packet.captured = true;
      } else {
        packet = generateICMPPacket(this.victim, '8.8.8.8');
        packet.captured = true;
      }

      this.io.emit('packet:captured', packet);
      if (this.attack) this.attack.packetsGenerated++;
    }, speed * 2);

    this.intervalIds.push(trafficInterval);

    if (config.autoStop && config.duration > 0) {
      const stopTimer = setTimeout(() => this.stop(), config.duration * 1000);
      this.intervalIds.push(stopTimer as unknown as NodeJS.Timeout);
    }

    return this.attack;
  }

  stop(): void {
    if (!this.attack) return;
    this.attack.status = 'stopped';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];

    if (this.victim) {
      this.io.emit('victim:status', { ...this.victim, status: 'idle' });
      this.log('success', `ARP cache restored for ${this.victim.hostname}`);
    }

    this.log('info', `ARP Spoofing attack stopped. Total packets: ${this.attack.packetsGenerated}`);
    this.io.emit('attack:stopped', this.attack.id);

    this.attack = null;
    this.victim = null;
  }

  mitigate(): void {
    if (!this.attack || !this.victim) return;
    this.attack.status = 'mitigated';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];

    this.log('success', `ARP cache locked - static entries enforced for ${this.victim.hostname}`);
    this.log('info', 'Mitigation: ARP cache hardening prevents poisoning');

    this.io.emit('victim:status', { ...this.victim, status: 'protected' });
    this.io.emit('attack:mitigated', this.attack.id);

    this.attack = null;
    this.victim = null;
  }

  private log(level: LogEntry['level'], message: string): void {
    this.io.emit('log:message', {
      timestamp: Date.now(),
      level,
      message,
      module: 'ARP Spoof',
    });
  }
}
