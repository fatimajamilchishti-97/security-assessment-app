import { Server } from 'socket.io';
import { v4 as uuid } from 'uuid';
import { AttackState, AttackConfig, VictimDevice, DNSQueryEntry, LogEntry } from '../types';
import { generateDNSPacket, generateHTTPPacket } from '../simulation/packetGenerator';
import { COMMON_WEBSITES, FAKE_CREDENTIALS } from '../simulation/victimProfiles';

const SPOOF_MAP: Record<string, string> = {
  'facebook.com': '192.168.1.50',
  'google.com': '192.168.1.50',
  'banking-example.com': '192.168.1.50',
  'university.edu': '192.168.1.50',
  'github.com': '192.168.1.50',
};

export class DNSSpoofingAttack {
  private io: Server;
  private attack: AttackState | null = null;
  private intervalIds: NodeJS.Timeout[] = [];
  private victim: VictimDevice | null = null;
  private queryQueue: string[] = [];

  constructor(io: Server) {
    this.io = io;
  }

  launch(victim: VictimDevice, config: AttackConfig): AttackState {
    this.victim = victim;
    this.queryQueue = [...COMMON_WEBSITES.map((w) => w.domain)];
    this.shuffleQueue();

    this.attack = {
      id: uuid(),
      type: 'dns_spoof',
      status: 'running',
      targetId: victim.id,
      startTime: Date.now(),
      packetsGenerated: 0,
      dataCaptured: {
        credentials: [],
        cookies: [],
        sessions: [],
        dnsQueries: [],
        modifiedPackets: 0,
        injectedContent: [],
      },
      config,
    };

    this.log('info', `DNS Spoofing attack launched against ${victim.hostname}`);
    this.log('attack', `DNS responses will be redirected to attacker IP: 192.168.1.50`);
    this.log('warn', `Victim will be served fake content for spoofed domains`);

    this.io.emit('attack:launched', this.attack);
    this.io.emit('victim:status', { ...victim, status: 'compromised' });

    const speed = config.aggressiveness === 'high' ? 800 : config.aggressiveness === 'medium' ? 1500 : 3000;

    const dnsInterval = setInterval(() => {
      if (!this.attack || this.attack.status !== 'running' || !this.victim) return;

      if (this.queryQueue.length === 0) {
        this.queryQueue = [...COMMON_WEBSITES.map((w) => w.domain)];
        this.shuffleQueue();
      }

      const domain = this.queryQueue.pop()!;
      const site = COMMON_WEBSITES.find((w) => w.domain === domain);
      const isSpoofed = SPOOF_MAP[domain] !== undefined;
      const spoofedIP = SPOOF_MAP[domain] || site?.ip || '0.0.0.0';
      const originalIP = site?.ip || '0.0.0.0';

      const packet = generateDNSPacket(this.victim, domain, isSpoofed, originalIP, spoofedIP);
      this.io.emit('packet:captured', packet);

      const dnsEntry: DNSQueryEntry = {
        id: uuid(),
        timestamp: Date.now(),
        query: domain,
        originalIP,
        spoofedIP: isSpoofed,
        resolvedIP: isSpoofed ? spoofedIP : originalIP,
        type: 'A',
      };

      if (this.attack) {
        this.attack.packetsGenerated++;
        this.attack.dataCaptured.dnsQueries.push(dnsEntry);
        if (isSpoofed) this.attack.dataCaptured.modifiedPackets++;
        this.io.emit('data:captured', this.attack.id, { dnsQueries: [dnsEntry] });
      }

      if (isSpoofed && Math.random() < 0.3) {
        const cred = FAKE_CREDENTIALS[Math.floor(Math.random() * FAKE_CREDENTIALS.length)];
        const httpPacket = generateHTTPPacket(this.victim, 'POST', `http://${domain}/login`, true, cred);
        this.io.emit('packet:captured', httpPacket);

        if (this.attack) {
          this.attack.packetsGenerated++;
          this.attack.dataCaptured.credentials.push({
            id: uuid(),
            timestamp: Date.now(),
            source: 'dns_spoof',
            url: domain,
            username: cred.username,
            password: cred.password,
            method: 'post',
          });
          this.io.emit('data:captured', this.attack.id, {
            credentials: [this.attack.dataCaptured.credentials[this.attack.dataCaptured.credentials.length - 1]],
          });
          this.log('attack', `Credential captured via DNS spoof: ${cred.username}@${domain}`);
        }
      }
    }, speed);

    this.intervalIds.push(dnsInterval);

    if (config.autoStop && config.duration > 0) {
      const stopTimer = setTimeout(() => this.stop(), config.duration * 1000);
      this.intervalIds.push(stopTimer as unknown as NodeJS.Timeout);
    }

    return this.attack;
  }

  stop(): void {
    if (!this.attack) return;
    this.attack.status = 'stopped';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];

    if (this.victim) {
      this.io.emit('victim:status', { ...this.victim, status: 'idle' });
    }
    this.log('info', `DNS Spoofing stopped. ${this.attack.dataCaptured.dnsQueries.length} queries intercepted.`);
    this.io.emit('attack:stopped', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  mitigate(): void {
    if (!this.attack || !this.victim) return;
    this.attack.status = 'mitigated';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];

    this.log('success', `DNSSEC validation enabled - spoofed responses rejected`);
    this.log('info', 'Mitigation: DNS responses now verified against trusted signatures');

    this.io.emit('victim:status', { ...this.victim, status: 'protected' });
    this.io.emit('attack:mitigated', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  private shuffleQueue(): void {
    for (let i = this.queryQueue.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [this.queryQueue[i], this.queryQueue[j]] = [this.queryQueue[j], this.queryQueue[i]];
    }
  }

  private log(level: LogEntry['level'], message: string): void {
    this.io.emit('log:message', { timestamp: Date.now(), level, message, module: 'DNS Spoof' });
  }
}
