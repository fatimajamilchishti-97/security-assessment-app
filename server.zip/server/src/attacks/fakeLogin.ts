import { Server } from 'socket.io';
import { v4 as uuid } from 'uuid';
import { AttackState, AttackConfig, VictimDevice, CredentialEntry, LogEntry } from '../types';
import { generateHTTPPacket, generateDNSPacket } from '../simulation/packetGenerator';
import { FAKE_CREDENTIALS, COMMON_WEBSITES } from '../simulation/victimProfiles';

export class FakeLoginAttack {
  private io: Server;
  private attack: AttackState | null = null;
  private intervalIds: NodeJS.Timeout[] = [];
  private victim: VictimDevice | null = null;

  constructor(io: Server) {
    this.io = io;
  }

  launch(victim: VictimDevice, config: AttackConfig): AttackState {
    this.victim = victim;
    this.attack = {
      id: uuid(),
      type: 'fake_login',
      status: 'running',
      targetId: victim.id,
      startTime: Date.now(),
      packetsGenerated: 0,
      dataCaptured: {
        credentials: [],
        cookies: [],
        sessions: [],
        dnsQueries: [],
        modifiedPackets: 0,
        injectedContent: ['Fake login page injected for university.edu', 'Credential harvesting form served'],
      },
      config,
    };

    this.log('info', `Fake Login Page attack deployed against ${victim.hostname}`);
    this.log('attack', 'Serving cloned login portal at intercepted URL');
    this.log('warn', 'Victim sees legitimate-looking page - URL appears correct');

    this.io.emit('attack:launched', this.attack);
    this.io.emit('victim:status', { ...victim, status: 'compromised' });

    const dnsPacket = generateDNSPacket(victim, 'login.university.edu', true, '10.0.0.10', '192.168.1.50');
    this.io.emit('packet:captured', dnsPacket);
    if (this.attack) this.attack.packetsGenerated++;

    const speed = config.aggressiveness === 'high' ? 2000 : config.aggressiveness === 'medium' ? 4000 : 7000;

    const loginInterval = setInterval(() => {
      if (!this.attack || this.attack.status !== 'running' || !this.victim) return;

      const cred = FAKE_CREDENTIALS[Math.floor(Math.random() * FAKE_CREDENTIALS.length)];
      const site = COMMON_WEBSITES.find((w) => !w.secure) || COMMON_WEBSITES[0];

      const getPacket = generateHTTPPacket(this.victim, 'GET', `http://${site.domain}/login`, true);
      this.io.emit('packet:captured', getPacket);
      if (this.attack) this.attack.packetsGenerated++;

      const postPacket = generateHTTPPacket(this.victim, 'POST', `http://${site.domain}/login`, true, cred);
      postPacket.info = `POST to fake login - credentials captured: ${cred.username}`;
      this.io.emit('packet:captured', postPacket);
      if (this.attack) {
        this.attack.packetsGenerated++;
        this.attack.dataCaptured.modifiedPackets += 2;
        const entry: CredentialEntry = {
          id: uuid(),
          timestamp: Date.now(),
          source: 'fake_login',
          url: site.domain,
          username: cred.username,
          password: cred.password,
          method: 'form',
        };
        this.attack.dataCaptured.credentials.push(entry);
        this.io.emit('data:captured', this.attack.id, { credentials: [entry] });
        this.log('attack', `FAKE LOGIN CAPTURED: ${cred.username} / ${cred.password} @ ${site.domain}`);
      }

      const redirectPacket = generateHTTPPacket(
        { ...this.victim, ip: site.ip },
        'GET',
        `http://${site.domain}/`,
        true
      );
      redirectPacket.sourceIP = site.ip;
      redirectPacket.destIP = this.victim.ip;
      redirectPacket.info = 'HTTP 302 Redirect -> Real site (victim unaware of theft)';
      this.io.emit('packet:captured', redirectPacket);
      if (this.attack) this.attack.packetsGenerated++;
    }, speed);

    this.intervalIds.push(loginInterval);

    if (config.autoStop && config.duration > 0) {
      const stopTimer = setTimeout(() => this.stop(), config.duration * 1000);
      this.intervalIds.push(stopTimer as unknown as NodeJS.Timeout);
    }

    return this.attack;
  }

  stop(): void {
    if (!this.attack) return;
    this.attack.status = 'stopped';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];
    if (this.victim) this.io.emit('victim:status', { ...this.victim, status: 'idle' });
    this.log('info', `Fake Login stopped. ${this.attack.dataCaptured.credentials.length} credentials harvested.`);
    this.io.emit('attack:stopped', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  mitigate(): void {
    if (!this.attack || !this.victim) return;
    this.attack.status = 'mitigated';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];
    this.log('success', 'Certificate Pinning enabled - fake certs rejected by client');
    this.log('info', 'Mitigation: App validates certificate fingerprint against known value');
    this.io.emit('victim:status', { ...this.victim, status: 'protected' });
    this.io.emit('attack:mitigated', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  private log(level: LogEntry['level'], message: string): void {
    this.io.emit('log:message', { timestamp: Date.now(), level, message, module: 'Fake Login' });
  }
}
