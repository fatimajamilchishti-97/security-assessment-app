import { Server } from 'socket.io';
import { v4 as uuid } from 'uuid';
import { AttackState, AttackConfig, VictimDevice, SimulatedPacket, LogEntry } from '../types';
import { generateTCPPacket, generateICMPPacket, generateARPPacket, generateTLSPacket } from '../simulation/packetGenerator';
import { GATEWAY, COMMON_WEBSITES } from '../simulation/victimProfiles';

export class PacketSniffingAttack {
  private io: Server;
  private attack: AttackState | null = null;
  private intervalIds: NodeJS.Timeout[] = [];
  private victim: VictimDevice | null = null;

  constructor(io: Server) {
    this.io = io;
  }

  launch(victim: VictimDevice, config: AttackConfig): AttackState {
    this.victim = victim;
    this.attack = {
      id: uuid(),
      type: 'packet_sniff',
      status: 'running',
      targetId: victim.id,
      startTime: Date.now(),
      packetsGenerated: 0,
      dataCaptured: {
        credentials: [],
        cookies: [],
        sessions: [],
        dnsQueries: [],
        modifiedPackets: 0,
        injectedContent: [],
      },
      config,
    };

    this.log('info', `Packet Sniffing started on ${victim.hostname}'s traffic`);
    this.log('attack', 'Network interface in promiscuous mode - capturing all frames');
    this.log('info', 'Passive capture - victim is unaware');

    this.io.emit('attack:launched', this.attack);
    this.io.emit('victim:status', { ...victim, status: 'active' });

    const speed = config.aggressiveness === 'high' ? 200 : config.aggressiveness === 'medium' ? 500 : 1000;

    const sniffInterval = setInterval(() => {
      if (!this.attack || this.attack.status !== 'running' || !this.victim) return;

      const rand = Math.random();
      let packet: SimulatedPacket;

      if (rand < 0.15) {
        packet = generateARPPacket(this.victim, false, GATEWAY.ip);
        packet.captured = true;
      } else if (rand < 0.25) {
        packet = generateICMPPacket(this.victim, '8.8.8.8');
        packet.captured = true;
      } else if (rand < 0.5) {
        const site = COMMON_WEBSITES[Math.floor(Math.random() * COMMON_WEBSITES.length)];
        packet = generateTLSPacket(
          this.victim,
          site.domain,
          (['ClientHello', 'ServerHello', 'Certificate', 'Finished'] as const)[Math.floor(Math.random() * 4)]
        );
        packet.captured = true;
      } else {
        packet = generateTCPPacket(
          this.victim.ip,
          COMMON_WEBSITES[Math.floor(Math.random() * COMMON_WEBSITES.length)].ip,
          this.victim.mac,
          GATEWAY.mac,
          ['SYN', 'ACK', 'PSH,ACK', 'FIN,ACK', 'RST'][Math.floor(Math.random() * 5)],
          40 + Math.floor(Math.random() * 1400)
        );
        packet.captured = true;
      }

      this.io.emit('packet:captured', packet);
      if (this.attack) this.attack.packetsGenerated++;
    }, speed);

    this.intervalIds.push(sniffInterval);

    if (config.autoStop && config.duration > 0) {
      const stopTimer = setTimeout(() => this.stop(), config.duration * 1000);
      this.intervalIds.push(stopTimer as unknown as NodeJS.Timeout);
    }

    return this.attack;
  }

  stop(): void {
    if (!this.attack) return;
    this.attack.status = 'stopped';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];
    if (this.victim) this.io.emit('victim:status', { ...this.victim, status: 'idle' });
    this.log('info', `Packet Sniffing stopped. ${this.attack.packetsGenerated} packets captured.`);
    this.io.emit('attack:stopped', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  mitigate(): void {
    if (!this.attack || !this.victim) return;
    this.attack.status = 'mitigated';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];
    this.log('success', 'Network switched to encrypted switched fabric - sniffing blocked');
    this.log('info', 'Mitigation: VPN tunnel encrypts all traffic, rendering captured packets unreadable');
    this.io.emit('victim:status', { ...this.victim, status: 'protected' });
    this.io.emit('attack:mitigated', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  private log(level: LogEntry['level'], message: string): void {
    this.io.emit('log:message', { timestamp: Date.now(), level, message, module: 'Packet Sniff' });
  }
}
