import { Server } from 'socket.io';
import { v4 as uuid } from 'uuid';
import { AttackState, AttackConfig, VictimDevice, SessionEntry, SimulatedPacket, LogEntry } from '../types';
import { generateHTTPPacket, generateTCPPacket } from '../simulation/packetGenerator';
import { COMMON_WEBSITES, FAKE_SESSIONS, FAKE_COOKIES } from '../simulation/victimProfiles';

export class SessionHijackingAttack {
  private io: Server;
  private attack: AttackState | null = null;
  private intervalIds: NodeJS.Timeout[] = [];
  private victim: VictimDevice | null = null;

  constructor(io: Server) {
    this.io = io;
  }

  launch(victim: VictimDevice, config: AttackConfig): AttackState {
    this.victim = victim;
    this.attack = {
      id: uuid(),
      type: 'session_hijack',
      status: 'running',
      targetId: victim.id,
      startTime: Date.now(),
      packetsGenerated: 0,
      dataCaptured: {
        credentials: [],
        cookies: [],
        sessions: [],
        dnsQueries: [],
        modifiedPackets: 0,
        injectedContent: [],
      },
      config,
    };

    this.log('info', `Session Hijacking attack launched against ${victim.hostname}`);
    this.log('attack', 'Sniffing for session tokens in unencrypted traffic');
    this.log('warn', 'Captured sessions can be used to impersonate the victim');

    this.io.emit('attack:launched', this.attack);
    this.io.emit('victim:status', { ...victim, status: 'compromised' });

    const speed = config.aggressiveness === 'high' ? 700 : config.aggressiveness === 'medium' ? 1500 : 3000;

    const hijackInterval = setInterval(() => {
      if (!this.attack || this.attack.status !== 'running' || !this.victim) return;

      const insecureSites = COMMON_WEBSITES.filter((w) => !w.secure);
      const target = insecureSites[Math.floor(Math.random() * insecureSites.length)];

      const tcpPkt = generateTCPPacket(
        this.victim.ip,
        target.ip,
        this.victim.mac,
        'FF:FF:FF:00:00:01',
        'PSH,ACK',
        200 + Math.floor(Math.random() * 800)
      );
      tcpPkt.captured = true;
      this.io.emit('packet:captured', tcpPkt);
      if (this.attack) this.attack.packetsGenerated++;

      const httpPkt = generateHTTPPacket(this.victim, 'GET', `http://${target.domain}/dashboard`, false);
      httpPkt.protocol = 'HTTP';
      httpPkt.payload += `Cookie: session=${FAKE_SESSIONS[Math.floor(Math.random() * FAKE_SESSIONS.length)].sessionId}\r\n`;
      httpPkt.info = `HTTP GET with session cookie (UNENCRYPTED)`;
      httpPkt.captured = true;
      this.io.emit('packet:captured', httpPkt);
      if (this.attack) this.attack.packetsGenerated++;

      if (Math.random() < 0.4) {
        const fakeSession = FAKE_SESSIONS[Math.floor(Math.random() * FAKE_SESSIONS.length)];
        const sessionEntry: SessionEntry = {
          id: uuid(),
          timestamp: Date.now(),
          domain: target.domain,
          sessionId: fakeSession.sessionId,
          userId: fakeSession.userId,
          expiry: fakeSession.expiry,
        };

        const fakeCookie = FAKE_COOKIES[Math.floor(Math.random() * FAKE_COOKIES.length)];
        const cookieEntry = {
          id: uuid(),
          timestamp: Date.now(),
          domain: fakeCookie.domain,
          name: fakeCookie.name,
          value: fakeCookie.value,
          httpOnly: fakeCookie.httpOnly,
          secure: fakeCookie.secure,
          path: fakeCookie.path,
        };

        if (this.attack) {
          this.attack.dataCaptured.sessions.push(sessionEntry);
          this.attack.dataCaptured.cookies.push(cookieEntry);
          this.io.emit('data:captured', this.attack.id, {
            sessions: [sessionEntry],
            cookies: [cookieEntry],
          });
          this.log('attack', `Session hijacked: ${sessionEntry.sessionId} @ ${target.domain} (user: ${sessionEntry.userId})`);
          this.log('warn', `Cookie stolen: ${cookieEntry.name}=${cookieEntry.value.substring(0, 16)}... @ ${cookieEntry.domain}`);
        }

        const hijackPacket = generateTCPWithSession(target.domain, sessionEntry.sessionId);
        this.io.emit('packet:captured', hijackPacket);
        if (this.attack) this.attack.packetsGenerated++;
      }
    }, speed);

    this.intervalIds.push(hijackInterval);

    if (config.autoStop && config.duration > 0) {
      const stopTimer = setTimeout(() => this.stop(), config.duration * 1000);
      this.intervalIds.push(stopTimer as unknown as NodeJS.Timeout);
    }

    return this.attack;
  }

  stop(): void {
    if (!this.attack) return;
    this.attack.status = 'stopped';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];
    if (this.victim) this.io.emit('victim:status', { ...this.victim, status: 'idle' });
    this.log('info', `Session Hijacking stopped. ${this.attack.dataCaptured.sessions.length} sessions captured.`);
    this.io.emit('attack:stopped', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  mitigate(): void {
    if (!this.attack || !this.victim) return;
    this.attack.status = 'mitigated';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];
    this.log('success', 'Session cookies now marked Secure + HttpOnly + SameSite=Strict');
    this.log('info', 'Mitigation: Cookie flags prevent JavaScript access and transmission over HTTP');
    this.io.emit('victim:status', { ...this.victim, status: 'protected' });
    this.io.emit('attack:mitigated', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  private log(level: LogEntry['level'], message: string): void {
    this.io.emit('log:message', { timestamp: Date.now(), level, message, module: 'Session Hijack' });
  }
}

function generateTCPWithSession(domain: string, sessionId: string): SimulatedPacket {
  return {
    id: uuid(),
    timestamp: Date.now(),
    sourceIP: '192.168.1.50',
    sourceMAC: 'DE:AD:BE:EF:00:01',
    destIP: COMMON_WEBSITES.find((w) => w.domain === domain)?.ip || '0.0.0.0',
    destMAC: 'FF:FF:FF:00:00:01',
    protocol: 'HTTP',
    sourcePort: 49152 + Math.floor(Math.random() * 16383),
    destPort: 80,
    size: 350,
    payload: `GET /dashboard HTTP/1.1\r\nHost: ${domain}\r\nCookie: session=${sessionId}\r\n`,
    hexDump: '',
    info: `HIJACKED SESSION - Attacker using stolen token: ${sessionId.substring(0, 16)}...`,
    modified: true,
    captured: true,
    raw: [
      `HTTP Request (HIJACKED)`,
      `    Source: ATTACKER (192.168.1.50)`,
      `    Destination: ${domain}`,
      `    Cookie: session=${sessionId}`,
      `    [ATTACKER IMPERSONATING VICTIM]`,
    ],
  };
}
