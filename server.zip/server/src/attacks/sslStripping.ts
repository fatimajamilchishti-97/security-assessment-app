import { Server } from 'socket.io';
import { v4 as uuid } from 'uuid';
import { AttackState, AttackConfig, VictimDevice, LogEntry } from '../types';
import { generateHTTPPacket, generateTLSPacket, generateTCPPacket } from '../simulation/packetGenerator';
import { COMMON_WEBSITES, FAKE_CREDENTIALS } from '../simulation/victimProfiles';

export class SSLStrippingAttack {
  private io: Server;
  private attack: AttackState | null = null;
  private intervalIds: NodeJS.Timeout[] = [];
  private victim: VictimDevice | null = null;

  constructor(io: Server) {
    this.io = io;
  }

  launch(victim: VictimDevice, config: AttackConfig): AttackState {
    this.victim = victim;
    this.attack = {
      id: uuid(),
      type: 'ssl_strip',
      status: 'running',
      targetId: victim.id,
      startTime: Date.now(),
      packetsGenerated: 0,
      dataCaptured: {
        credentials: [],
        cookies: [],
        sessions: [],
        dnsQueries: [],
        modifiedPackets: 0,
        injectedContent: [],
      },
      config,
    };

    this.log('info', `SSL Stripping attack launched against ${victim.hostname}`);
    this.log('attack', 'Intercepting HTTPS connections and downgrading to HTTP');
    this.log('warn', 'Victim sees padlock icon but traffic is actually plaintext');

    this.io.emit('attack:launched', this.attack);
    this.io.emit('victim:status', { ...victim, status: 'compromised' });

    const speed = config.aggressiveness === 'high' ? 600 : config.aggressiveness === 'medium' ? 1200 : 2500;

    const stripInterval = setInterval(() => {
      if (!this.attack || this.attack.status !== 'running' || !this.victim) return;

      const secureSite = COMMON_WEBSITES.filter((w) => w.secure);
      const target = secureSite[Math.floor(Math.random() * secureSite.length)];

      const tlsPacket = generateTLSPacket(this.victim, target.domain, 'ClientHello');
      this.io.emit('packet:captured', tlsPacket);
      if (this.attack) this.attack.packetsGenerated++;

      const strippedPacket = generateHTTPPacket(
        this.victim,
        'GET',
        `http://${target.domain}/`,
        true
      );
      this.io.emit('packet:captured', strippedPacket);
      if (this.attack) {
        this.attack.packetsGenerated++;
        this.attack.dataCaptured.modifiedPackets++;
      }

      const responsePacket = generateHTTPPacket(
        { ...this.victim, ip: target.ip, mac: '00:00:00:00:00:02' },
        'GET',
        `http://${target.domain}/`,
        true
      );
      responsePacket.sourceIP = target.ip;
      responsePacket.destIP = this.victim.ip;
      responsePacket.info = `HTTP 200 OK (stripped from HTTPS) - Content injected`;
      this.io.emit('packet:captured', responsePacket);
      if (this.attack) {
        this.attack.packetsGenerated++;
        this.attack.dataCaptured.modifiedPackets++;
      }

      if (Math.random() < 0.25) {
        const cred = FAKE_CREDENTIALS[Math.floor(Math.random() * FAKE_CREDENTIALS.length)];
        const postPacket = generateHTTPPacket(
          this.victim,
          'POST',
          `http://${target.domain}/login`,
          true,
          cred
        );
        this.io.emit('packet:captured', postPacket);
        if (this.attack) {
          this.attack.packetsGenerated++;
          const captured = {
            id: uuid(),
            timestamp: Date.now(),
            source: 'ssl_strip',
            url: target.domain,
            username: cred.username,
            password: cred.password,
            method: 'post' as const,
          };
          this.attack.dataCaptured.credentials.push(captured);
          this.io.emit('data:captured', this.attack.id, { credentials: [captured] });
          this.log('attack', `SSL-STRIPPED credential: ${cred.username}:${cred.password} @ ${target.domain}`);
        }
      }
    }, speed);

    this.intervalIds.push(stripInterval);

    const bgTraffic = setInterval(() => {
      if (!this.attack || this.attack.status !== 'running' || !this.victim) return;
      const tcp = generateTCPPacket(
        this.victim.ip,
        '142.250.80.46',
        this.victim.mac,
        'FF:FF:FF:00:00:01',
        ['SYN', 'ACK', 'PSH,ACK'][Math.floor(Math.random() * 3)],
        40 + Math.floor(Math.random() * 800)
      );
      this.io.emit('packet:captured', tcp);
      if (this.attack) this.attack.packetsGenerated++;
    }, speed * 3);

    this.intervalIds.push(bgTraffic);

    if (config.autoStop && config.duration > 0) {
      const stopTimer = setTimeout(() => this.stop(), config.duration * 1000);
      this.intervalIds.push(stopTimer as unknown as NodeJS.Timeout);
    }

    return this.attack;
  }

  stop(): void {
    if (!this.attack) return;
    this.attack.status = 'stopped';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];
    if (this.victim) this.io.emit('victim:status', { ...this.victim, status: 'idle' });
    this.log('info', `SSL Stripping stopped. ${this.attack.dataCaptured.modifiedPackets} connections downgraded.`);
    this.io.emit('attack:stopped', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  mitigate(): void {
    if (!this.attack || !this.victim) return;
    this.attack.status = 'mitigated';
    this.intervalIds.forEach(clearInterval);
    this.intervalIds = [];
    this.log('success', 'HSTS enabled - browser refuses HTTP connections to known HTTPS sites');
    this.log('info', 'Mitigation: HSTS header forces HTTPS, stripping becomes impossible');
    this.io.emit('victim:status', { ...this.victim, status: 'protected' });
    this.io.emit('attack:mitigated', this.attack.id);
    this.attack = null;
    this.victim = null;
  }

  private log(level: LogEntry['level'], message: string): void {
    this.io.emit('log:message', { timestamp: Date.now(), level, message, module: 'SSL Strip' });
  }
}
