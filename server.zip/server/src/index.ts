import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import { AttackType, AttackConfig, MitigationState, DashboardStats, AttackState, VictimDevice } from './types';
import { NetworkTopology } from './simulation/networkTopology';
import { VICTIM_PROFILES } from './simulation/victimProfiles';
import { ARPSpoofingAttack } from './attacks/arpSpoofing';
import { DNSSpoofingAttack } from './attacks/dnsSpoofing';
import { SSLStrippingAttack } from './attacks/sslStripping';
import { SessionHijackingAttack } from './attacks/sessionHijacking';
import { PacketSniffingAttack } from './attacks/packetSniffing';
import { FakeLoginAttack } from './attacks/fakeLogin';
import { CookieStealingAttack } from './attacks/cookieStealing';

const app = express();
app.use(cors());
app.use(express.json());

const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: 'http://localhost:3000',
    methods: ['GET', 'POST'],
  },
});

interface AttackInstance {
  launch(victim: VictimDevice, config: AttackConfig): AttackState;
  stop(): void;
  mitigate(): void;
}

interface ActiveAttackEntry {
  instance: AttackInstance;
  state: AttackState;
}

const topology = new NetworkTopology();
const activeAttacks = new Map<string, ActiveAttackEntry>();

// Cumulative totals for attacks that have already ended, so the dashboard
// counters keep growing instead of dropping to zero when an attack stops.
let completedPackets = 0;
let completedModified = 0;
let completedCreds = 0;
let lastTotalPackets = 0;

const stats: DashboardStats = {
  totalPackets: 0,
  capturedPackets: 0,
  modifiedPackets: 0,
  activeAttacks: 0,
  compromisedDevices: 0,
  credentialsCaptured: 0,
  packetsPerSecond: 0,
  attackTimeline: [],
};

const mitigationState: MitigationState = {
  httpsEverywhere: false,
  hsts: false,
  certPinning: false,
  arpCacheSecurity: false,
  vpnActive: false,
  dnssec: false,
  securityScore: 0,
};

function getAttackInstance(type: AttackType): AttackInstance | null {
  switch (type) {
    case 'arp_spoof': return new ARPSpoofingAttack(io);
    case 'dns_spoof': return new DNSSpoofingAttack(io);
    case 'ssl_strip': return new SSLStrippingAttack(io);
    case 'session_hijack': return new SessionHijackingAttack(io);
    case 'packet_sniff': return new PacketSniffingAttack(io);
    case 'fake_login': return new FakeLoginAttack(io);
    case 'cookie_steal': return new CookieStealingAttack(io);
    default: return null;
  }
}

function computeSecurityScore(): number {
  let score = 0;
  if (mitigationState.httpsEverywhere) score += 15;
  if (mitigationState.hsts) score += 20;
  if (mitigationState.certPinning) score += 15;
  if (mitigationState.arpCacheSecurity) score += 15;
  if (mitigationState.vpnActive) score += 20;
  if (mitigationState.dnssec) score += 15;
  return score;
}

function finalizeAttack(attackId: string): void {
  const entry = activeAttacks.get(attackId);
  if (!entry) return;
  completedPackets += entry.state.packetsGenerated;
  completedModified += entry.state.dataCaptured.modifiedPackets;
  completedCreds += entry.state.dataCaptured.credentials.length;
  activeAttacks.delete(attackId);
  topology.setConnectionIntercepted(entry.state.targetId, false);
}

function updateStats(): void {
  let activePackets = 0;
  let activeModified = 0;
  let activeCreds = 0;
  let compromised = 0;

  activeAttacks.forEach(({ state }) => {
    activePackets += state.packetsGenerated;
    activeModified += state.dataCaptured.modifiedPackets;
    activeCreds += state.dataCaptured.credentials.length;
  });

  topology.getAllDevices().forEach((d) => {
    if (d.status === 'compromised') compromised++;
  });

  stats.totalPackets = completedPackets + activePackets;
  stats.capturedPackets = completedPackets + activePackets;
  stats.modifiedPackets = completedModified + activeModified;
  stats.credentialsCaptured = completedCreds + activeCreds;
  stats.activeAttacks = activeAttacks.size;
  stats.compromisedDevices = compromised;
  stats.packetsPerSecond = Math.max(0, Math.round((stats.totalPackets - lastTotalPackets) / 2));
  lastTotalPackets = stats.totalPackets;

  const now = new Date();
  stats.attackTimeline.push({
    time: `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`,
    count: stats.totalPackets,
  });
  if (stats.attackTimeline.length > 30) stats.attackTimeline.shift();

  io.emit('stats:update', stats);
}

io.on('connection', (socket) => {
  console.log(`[+] Client connected: ${socket.id}`);

  socket.emit('topology:update', topology.getFullTopology());
  socket.emit('mitigation:update', mitigationState);
  socket.emit('stats:update', stats);
  socket.emit('victims:list', topology.getAllDevices());

  socket.on('attack:launch', (data: { type: AttackType; victimId: string; config: AttackConfig }) => {
    const victim = topology.getDevice(data.victimId);
    if (!victim) {
      socket.emit('log:message', { timestamp: Date.now(), level: 'error', message: 'Victim not found', module: 'System' });
      return;
    }

    const instance = getAttackInstance(data.type);
    if (!instance) return;

    const state = instance.launch(victim, data.config);
    activeAttacks.set(state.id, { instance, state });

    topology.setConnectionIntercepted(data.victimId, true);
    topology.updateDeviceStatus(data.victimId, data.type === 'packet_sniff' ? 'active' : 'compromised');
    io.emit('topology:update', topology.getFullTopology());
    updateStats();

    // Server-side auto-stop cleanup so the active-attack map and topology stay
    // consistent once the attack's own timer clears its intervals.
    if (data.config.autoStop && data.config.duration > 0) {
      setTimeout(() => {
        const entry = activeAttacks.get(state.id);
        if (entry) {
          entry.instance.stop();
          finalizeAttack(state.id);
          topology.updateDeviceStatus(state.targetId, 'idle');
          io.emit('topology:update', topology.getFullTopology());
          updateStats();
        }
      }, data.config.duration * 1000);
    }
  });

  socket.on('attack:stop', (attackId: string) => {
    const entry = activeAttacks.get(attackId);
    if (!entry) return;
    entry.instance.stop();
    const targetId = entry.state.targetId;
    finalizeAttack(attackId);
    topology.updateDeviceStatus(targetId, 'idle');
    io.emit('topology:update', topology.getFullTopology());
    updateStats();
  });

  socket.on('attack:mitigate', (attackId: string) => {
    const entry = activeAttacks.get(attackId);
    if (!entry) return;
    entry.instance.mitigate();
    const targetId = entry.state.targetId;
    finalizeAttack(attackId);
    topology.updateDeviceStatus(targetId, 'protected');
    io.emit('topology:update', topology.getFullTopology());
    updateStats();
  });

  socket.on('attack:stopAll', () => {
    activeAttacks.forEach((entry) => {
      entry.instance.stop();
      completedPackets += entry.state.packetsGenerated;
      completedModified += entry.state.dataCaptured.modifiedPackets;
      completedCreds += entry.state.dataCaptured.credentials.length;
    });
    activeAttacks.clear();
    topology.resetAll();
    io.emit('topology:update', topology.getFullTopology());
    updateStats();
    io.emit('log:message', { timestamp: Date.now(), level: 'info', message: 'All attacks stopped, network reset', module: 'System' });
  });

  socket.on('mitigation:toggle', (data: { key: keyof MitigationState; value: boolean }) => {
    if (data.key === 'securityScore') return;
    mitigationState[data.key] = data.value;
    mitigationState.securityScore = computeSecurityScore();
    io.emit('mitigation:update', mitigationState);
    updateStats();

    if (data.value) {
      io.emit('log:message', {
        timestamp: Date.now(),
        level: 'success',
        message: `Mitigation enabled: ${data.key}`,
        module: 'Defense',
      });
    }
  });

  socket.on('topology:request', () => {
    socket.emit('topology:update', topology.getFullTopology());
  });

  socket.on('victims:request', () => {
    socket.emit('victims:list', topology.getAllDevices());
  });

  socket.on('disconnect', () => {
    console.log(`[-] Client disconnected: ${socket.id}`);
  });
});

setInterval(updateStats, 2000);

app.get('/api/health', (_req, res) => {
  res.json({ status: 'running', activeAttacks: activeAttacks.size, uptime: process.uptime() });
});

app.get('/api/victims', (_req, res) => {
  res.json(topology.getAllDevices());
});

app.get('/api/topology', (_req, res) => {
  res.json(topology.getFullTopology());
});

app.get('/api/stats', (_req, res) => {
  res.json(stats);
});

app.get('/api/mitigations', (_req, res) => {
  res.json(mitigationState);
});

const PORT = process.env.PORT || 4000;
httpServer.listen(PORT, () => {
  console.log(`[*] MITM Framework Server running on port ${PORT}`);
  console.log(`[*] Simulation mode: NO real network traffic is generated`);
  console.log(`[*] Victims loaded: ${VICTIM_PROFILES.length} simulated devices`);
});
