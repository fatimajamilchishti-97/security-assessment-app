import { VictimDevice, ConnectionInfo } from '../types';
import { VICTIM_PROFILES, GATEWAY, ATTACKER } from './victimProfiles';

export class NetworkTopology {
  private devices: Map<string, VictimDevice> = new Map();
  private connections: ConnectionInfo[] = [];

  constructor() {
    VICTIM_PROFILES.forEach((device) => this.devices.set(device.id, { ...device }));
    this.buildConnections();
  }

  private buildConnections(): void {
    this.connections = [];
    const deviceArray = Array.from(this.devices.values());

    for (const device of deviceArray) {
      this.connections.push({
        from: device.id,
        to: 'gateway',
        type: 'normal',
        bandwidth: device.trafficRate,
        packetCount: Math.floor(Math.random() * 1000),
      });
    }

    this.connections.push({
      from: 'attacker',
      to: 'gateway',
      type: 'normal',
      bandwidth: 0,
      packetCount: 0,
    });
  }

  getAllDevices(): VictimDevice[] {
    return Array.from(this.devices.values());
  }

  getDevice(id: string): VictimDevice | undefined {
    return this.devices.get(id);
  }

  updateDeviceStatus(id: string, status: VictimDevice['status']): void {
    const device = this.devices.get(id);
    if (device) {
      device.status = status;
      this.devices.set(id, device);
    }
  }

  getConnections(): ConnectionInfo[] {
    return [...this.connections];
  }

  setConnectionIntercepted(deviceId: string, intercepted: boolean): void {
    const conn = this.connections.find((c) => c.from === deviceId && c.to === 'gateway');
    if (conn) {
      conn.type = intercepted ? 'intercepted' : 'normal';
    }
  }

  setConnectionBlocked(deviceId: string, blocked: boolean): void {
    const conn = this.connections.find((c) => c.from === deviceId && c.to === 'gateway');
    if (conn) {
      conn.type = blocked ? 'blocked' : 'normal';
    }
  }

  getGatewayInfo() {
    return { ...GATEWAY, id: 'gateway' };
  }

  getAttackerInfo() {
    return { ...ATTACKER, id: 'attacker' };
  }

  getFullTopology(): { devices: VictimDevice[]; connections: ConnectionInfo[] } {
    return {
      devices: this.getAllDevices(),
      connections: this.getConnections(),
    };
  }

  resetAll(): void {
    this.devices.forEach((device, id) => {
      device.status = 'idle';
      this.devices.set(id, device);
    });
    this.buildConnections();
  }
}
