import { v4 as uuid } from 'uuid';
import { SimulatedPacket, VictimDevice } from '../types';
import { GATEWAY, ATTACKER, COMMON_WEBSITES } from './victimProfiles';

function randomMAC(): string {
  const hex = () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0').toUpperCase();
  return `${hex()}:${hex()}:${hex()}:${hex()}:${hex()}:${hex()}`;
}

function generateHexDump(payload: string, size: number): string {
  let hex = '';
  const bytes = Buffer.from(payload, 'utf8');
  for (let i = 0; i < Math.min(size, 256); i++) {
    const byte = i < bytes.length ? bytes[i] : Math.floor(Math.random() * 256);
    hex += byte.toString(16).padStart(2, '0').toUpperCase();
    if ((i + 1) % 2 === 0) hex += ' ';
    if ((i + 1) % 16 === 0) hex += '\n';
  }
  return hex;
}

function generateRawLines(payload: string, size: number): string[] {
  const lines: string[] = [];
  lines.push(`Frame ${Math.floor(Math.random() * 99999)}: ${size} bytes on wire`);
  lines.push('Ethernet II, Src: ' + randomMAC() + ', Dst: ' + randomMAC());
  lines.push(`    Type: IPv4 (0x0800)`);
  lines.push('Internet Protocol Version 4, Src: 0.0.0.0, Dst: 0.0.0.0');
  lines.push(`    Version: 4, Header Length: 20 bytes`);
  lines.push(`    Total Length: ${size}`);
  lines.push(`    Time to Live: ${64 - Math.floor(Math.random() * 30)}`);
  lines.push(`    Protocol: TCP (6)`);
  if (payload) {
    lines.push(`    [${Math.min(payload.length, 64)} bytes of payload]`);
  }
  return lines;
}

export function generateARPPacket(
  victim: VictimDevice,
  isPoison: boolean,
  targetIP: string
): SimulatedPacket {
  const spoofedMAC = isPoison ? ATTACKER.mac : GATEWAY.mac;
  const info = isPoison
    ? `ARP Reply: ${targetIP} is at ${ATTACKER.mac} (SPOOFED)`
    : `ARP Reply: ${targetIP} is at ${GATEWAY.mac}`;

  return {
    id: uuid(),
    timestamp: Date.now(),
    sourceIP: targetIP,
    sourceMAC: spoofedMAC,
    destIP: victim.ip,
    destMAC: victim.mac,
    protocol: 'ARP',
    size: 42,
    payload: isPoison
      ? `ARP-REPLY ${targetIP} -> ${ATTACKER.mac} [POISON]`
      : `ARP-REPLY ${targetIP} -> ${GATEWAY.mac}`,
    hexDump: generateHexDump(
      isPoison
        ? `ARP-REPLY ${targetIP} -> ${ATTACKER.mac}`
        : `ARP-REPLY ${targetIP} -> ${GATEWAY.mac}`,
      42
    ),
    info,
    modified: isPoison,
    captured: true,
    raw: generateRawLines(`ARP Reply: ${targetIP} is at ${spoofedMAC}`, 42),
  };
}

export function generateDNSPacket(
  victim: VictimDevice,
  query: string,
  isSpoofed: boolean,
  originalIP: string,
  spoofedIP: string
): SimulatedPacket {
  const info = isSpoofed
    ? `DNS Response: ${query} -> ${spoofedIP} (SPOOFED from ${originalIP})`
    : `DNS Response: ${query} -> ${originalIP}`;

  return {
    id: uuid(),
    timestamp: Date.now(),
    sourceIP: '8.8.8.8',
    sourceMAC: GATEWAY.mac,
    destIP: victim.ip,
    destMAC: victim.mac,
    protocol: 'DNS',
    size: isSpoofed ? 128 : 96,
    payload: isSpoofed
      ? `DNS-A ${query} -> ${spoofedIP} [SPOOFED]`
      : `DNS-A ${query} -> ${originalIP}`,
    hexDump: generateHexDump(
      `DNS Response ${query} ${isSpoofed ? spoofedIP : originalIP}`,
      isSpoofed ? 128 : 96
    ),
    info,
    modified: isSpoofed,
    captured: true,
    raw: [
      `DNS Response`,
      `    Transaction ID: 0x${Math.floor(Math.random() * 65535).toString(16)}`,
      `    Flags: 0x8180 Standard query response`,
      `    Questions: 1, Answers: 1`,
      `    ${query}: type A, class IN`,
      `    Answer: ${query} -> ${isSpoofed ? spoofedIP : originalIP}${isSpoofed ? ' [SPOOFED]' : ''}`,
    ],
  };
}

export function generateHTTPPacket(
  victim: VictimDevice,
  method: 'GET' | 'POST',
  url: string,
  isStripped: boolean,
  credentials?: { username: string; password: string }
): SimulatedPacket {
  const host = url.replace(/^https?:\/\//, '').split('/')[0];
  const path = url.replace(/^https?:\/\/[^/]+/, '') || '/';
  const port = isStripped ? 80 : 443;
  const protocol = isStripped ? 'HTTP' : 'HTTPS';
  let payload = '';

  if (method === 'GET') {
    payload = `${method} ${path} HTTP/1.1\r\nHost: ${host}\r\nUser-Agent: Mozilla/5.0\r\nAccept: text/html\r\n`;
    if (isStripped) {
      payload += `Connection: close\r\n`;
    }
  } else {
    payload = `${method} ${path} HTTP/1.1\r\nHost: ${host}\r\nContent-Type: application/x-www-form-urlencoded\r\n`;
    if (credentials) {
      const body = `username=${encodeURIComponent(credentials.username)}&password=${encodeURIComponent(credentials.password)}`;
      payload += `Content-Length: ${body.length}\r\n\r\n${body}`;
    }
  }

  const info = isStripped
    ? `${method} ${url} (DOWNGRADED to HTTP, credentials EXPOSED)`
    : `${method} ${url} (${protocol}, encrypted)`;

  return {
    id: uuid(),
    timestamp: Date.now(),
    sourceIP: victim.ip,
    sourceMAC: victim.mac,
    destIP: COMMON_WEBSITES.find((w) => w.domain === host)?.ip || '0.0.0.0',
    destMAC: GATEWAY.mac,
    protocol: isStripped ? 'HTTP' : 'HTTPS',
    sourcePort: 49152 + Math.floor(Math.random() * 16383),
    destPort: port,
    size: payload.length + 40,
    payload,
    hexDump: generateHexDump(payload, payload.length + 40),
    info,
    modified: isStripped,
    captured: isStripped || method === 'POST',
    raw: [
      `${protocol} ${method} Request`,
      `    Host: ${host}`,
      `    Path: ${path}`,
      `    Port: ${port}`,
      isStripped ? '    [SSL STRIPPED - Traffic is plaintext]' : '    [TLS Encrypted - Payload not visible]',
      credentials && isStripped ? `    [CREDENTIALS INTERCEPTED: ${credentials.username}:${credentials.password}]` : '',
    ].filter(Boolean),
  };
}

export function generateTCPPacket(
  sourceIP: string,
  destIP: string,
  sourceMAC: string,
  destMAC: string,
  flags: string,
  size: number
): SimulatedPacket {
  return {
    id: uuid(),
    timestamp: Date.now(),
    sourceIP,
    sourceMAC,
    destIP,
    destMAC,
    protocol: 'TCP',
    sourcePort: 49152 + Math.floor(Math.random() * 16383),
    destPort: [80, 443, 8080, 3000][Math.floor(Math.random() * 4)],
    size,
    payload: `TCP [${flags}] ${sourceIP}:${49152} -> ${destIP}:443`,
    hexDump: generateHexDump(`TCP ${flags}`, size),
    info: `TCP ${flags} ${sourceIP} → ${destIP}`,
    modified: false,
    captured: true,
    raw: [
      `TCP Segment`,
      `    Source Port: ${49152 + Math.floor(Math.random() * 16383)}`,
      `    Destination Port: 443`,
      `    Sequence Number: ${Math.floor(Math.random() * 4294967295)}`,
      `    Flags: ${flags}`,
      `    Window: ${65535 - Math.floor(Math.random() * 30000)}`,
    ],
  };
}

export function generateTLSPacket(
  victim: VictimDevice,
  domain: string,
  handshakeType: 'ClientHello' | 'ServerHello' | 'Certificate' | 'Finished'
): SimulatedPacket {
  const site = COMMON_WEBSITES.find((w) => w.domain === domain);
  const info = `TLS ${handshakeType} - ${domain}`;

  return {
    id: uuid(),
    timestamp: Date.now(),
    sourceIP: victim.ip,
    sourceMAC: victim.mac,
    destIP: site?.ip || '0.0.0.0',
    destMAC: GATEWAY.mac,
    protocol: 'TLS',
    sourcePort: 49152 + Math.floor(Math.random() * 16383),
    destPort: 443,
    size: handshakeType === 'Certificate' ? 1400 : 300 + Math.floor(Math.random() * 200),
    payload: `TLS 1.3 ${handshakeType} for ${domain}`,
    hexDump: generateHexDump(`TLS ${handshakeType} ${domain}`, 500),
    info,
    modified: false,
    captured: true,
    raw: [
      `TLSv1.3 Record Layer: ${handshakeType}`,
      `    Content Type: Handshake`,
      `    Version: TLS 1.3 (0x0304)`,
      `    Handshake Type: ${handshakeType}`,
      handshakeType === 'ClientHello'
        ? `    Cipher Suites: TLS_AES_256_GCM_SHA384, TLS_CHACHA20_POLY1305_SHA256`
        : '',
      handshakeType === 'Certificate'
        ? `    Subject: ${domain}, Issuer: Let's Encrypt Authority X3`
        : '',
    ].filter(Boolean),
  };
}

export function generateICMPPacket(victim: VictimDevice, destIP: string): SimulatedPacket {
  return {
    id: uuid(),
    timestamp: Date.now(),
    sourceIP: victim.ip,
    sourceMAC: victim.mac,
    destIP,
    destMAC: GATEWAY.mac,
    protocol: 'ICMP',
    size: 64,
    payload: 'Echo Request',
    hexDump: generateHexDump('ICMP Echo Request', 64),
    info: `ICMP Echo (ping) ${victim.ip} → ${destIP}`,
    modified: false,
    captured: false,
    raw: [
      'Internet Control Message Protocol',
      '    Type: 8 (Echo Request)',
      '    Code: 0',
      `    Identifier: ${Math.floor(Math.random() * 65535)}`,
      `    Sequence Number: ${Math.floor(Math.random() * 65535)}`,
      '    Data: 56 bytes of payload',
    ],
  };
}
