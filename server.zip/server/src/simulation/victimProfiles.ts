import { VictimDevice } from '../types';
import { v4 as uuid } from 'uuid';

export const VICTIM_PROFILES: VictimDevice[] = [
  {
    id: uuid(),
    hostname: 'STUDENT-LAPTOP-01',
    ip: '192.168.1.101',
    mac: 'AA:BB:CC:11:22:33',
    os: 'Windows 11',
    type: 'laptop',
    status: 'idle',
    openPorts: [80, 443, 8080, 3000],
    vulnerability: 'Outdated browser - no HSTS support',
    trafficRate: 45,
  },
  {
    id: uuid(),
    hostname: 'PROFESSOR-DESKTOP',
    ip: '192.168.1.102',
    mac: 'AA:BB:CC:44:55:66',
    os: 'macOS Sonoma',
    type: 'desktop',
    status: 'idle',
    openPorts: [22, 80, 443, 5900],
    vulnerability: 'VNC service exposed on LAN',
    trafficRate: 30,
  },
  {
    id: uuid(),
    hostname: 'IPHONE-ADMIN',
    ip: '192.168.1.103',
    mac: 'AA:BB:CC:77:88:99',
    os: 'iOS 17',
    type: 'phone',
    status: 'idle',
    openPorts: [443, 5223],
    vulnerability: 'Auto-connects to open WiFi',
    trafficRate: 60,
  },
  {
    id: uuid(),
    hostname: 'ANDROID-LAB-TAB',
    ip: '192.168.1.104',
    mac: 'AA:BB:CC:AA:BB:CC',
    os: 'Android 14',
    type: 'tablet',
    status: 'idle',
    openPorts: [443, 5228],
    vulnerability: 'No certificate pinning in lab app',
    trafficRate: 25,
  },
  {
    id: uuid(),
    hostname: 'SMART-PRINTER-3F',
    ip: '192.168.1.105',
    mac: 'AA:BB:CC:DD:EE:FF',
    os: 'Embedded Linux',
    type: 'iot',
    status: 'idle',
    openPorts: [80, 443, 9100, 631],
    vulnerability: 'Default credentials, no TLS',
    trafficRate: 5,
  },
  {
    id: uuid(),
    hostname: 'LAB-SERVER-01',
    ip: '192.168.1.200',
    mac: 'DD:EE:FF:11:22:33',
    os: 'Ubuntu 22.04 LTS',
    type: 'desktop',
    status: 'idle',
    openPorts: [22, 80, 443, 3306, 5432, 8080],
    vulnerability: 'MySQL exposed to LAN segment',
    trafficRate: 80,
  },
];

export const GATEWAY = {
  ip: '192.168.1.1',
  mac: 'FF:FF:FF:00:00:01',
  hostname: 'GATEWAY-ROUTER',
};

export const ATTACKER = {
  ip: '192.168.1.50',
  mac: 'DE:AD:BE:EF:00:01',
  hostname: 'ATTACKER-KALI',
};

export const COMMON_WEBSITES = [
  { domain: 'facebook.com', ip: '157.240.1.35', secure: true },
  { domain: 'google.com', ip: '142.250.80.46', secure: true },
  { domain: 'university.edu', ip: '10.0.0.5', secure: true },
  { domain: 'banking-example.com', ip: '203.0.113.50', secure: true },
  { domain: 'login.university.edu', ip: '10.0.0.10', secure: false },
  { domain: 'old-forum.com', ip: '198.51.100.23', secure: false },
  { domain: 'test-site.com', ip: '192.0.2.100', secure: false },
  { domain: 'github.com', ip: '140.82.121.4', secure: true },
  { domain: 'reddit.com', ip: '151.101.1.140', secure: true },
  { domain: 'http-only-site.com', ip: '198.51.100.45', secure: false },
];

export const FAKE_CREDENTIALS = [
  { username: 'jsmith2024', password: 'Password123!', url: 'facebook.com', method: 'post' as const },
  { username: 'admin@university.edu', password: 'UniAdm1n!', url: 'login.university.edu', method: 'form' as const },
  { username: 'student_jane', password: 'JaneDoe2024', url: 'old-forum.com', method: 'post' as const },
  { username: 'prof.williams', password: 'Pr0f3ss0r!', url: 'university.edu', method: 'basic_auth' as const },
  { username: 'lab_user', password: 'LabPass!2024', url: 'test-site.com', method: 'post' as const },
  { username: 'banking_user_01', password: 'B@nkS3cure99', url: 'banking-example.com', method: 'post' as const },
];

export const FAKE_COOKIES = [
  { domain: '.facebook.com', name: 'datr', value: 'a1b2c3d4e5f6g7h8i9j0', httpOnly: true, secure: true, path: '/' },
  { domain: '.university.edu', name: 'PHPSESSID', value: 'abc123def456ghi789', httpOnly: true, secure: false, path: '/' },
  { domain: '.github.com', name: '_gh_sess', value: 'xyz789uvw456rst123', httpOnly: true, secure: true, path: '/' },
  { domain: 'old-forum.com', name: 'session_id', value: 'forum_sess_88271', httpOnly: false, secure: false, path: '/' },
  { domain: '.reddit.com', name: 'reddit_session', value: 'r3dd1t_s3ss10n_t0k3n', httpOnly: true, secure: true, path: '/' },
  { domain: 'banking-example.com', name: 'auth_token', value: 'bnk_t0k3n_s3cur3_x9y8z7', httpOnly: true, secure: false, path: '/' },
];

export const FAKE_SESSIONS = [
  { domain: 'university.edu', sessionId: 'sess_a1b2c3d4e5f6', userId: 'jsmith2024', expiry: 3600 },
  { domain: 'facebook.com', sessionId: 'sess_x9y8z7w6v5u4', userId: '1000458237142', expiry: 7200 },
  { domain: 'github.com', sessionId: 'sess_m1n2o3p4q5r6', userId: 'devstudent01', expiry: 1800 },
  { domain: 'old-forum.com', sessionId: 'sess_k7l8m9n0o1p2', userId: 'forum_user_42', expiry: 86400 },
  { domain: 'banking-example.com', sessionId: 'sess_banking_secure_a1', userId: 'acct_882710', expiry: 900 },
];
