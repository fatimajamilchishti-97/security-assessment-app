export interface SimulatedPacket {
  id: string;
  timestamp: number;
  sourceIP: string;
  sourceMAC: string;
  destIP: string;
  destMAC: string;
  protocol: 'ARP' | 'DNS' | 'TCP' | 'HTTP' | 'HTTPS' | 'TLS' | 'ICMP';
  sourcePort?: number;
  destPort?: number;
  size: number;
  payload: string;
  hexDump: string;
  info: string;
  modified: boolean;
  captured: boolean;
  raw: string[];
}

export interface VictimDevice {
  id: string;
  hostname: string;
  ip: string;
  mac: string;
  os: string;
  type: 'laptop' | 'phone' | 'tablet' | 'desktop' | 'iot';
  status: 'idle' | 'active' | 'compromised' | 'protected';
  openPorts: number[];
  vulnerability: string;
  trafficRate: number;
}

export interface AttackState {
  id: string;
  type: AttackType;
  status: 'idle' | 'running' | 'stopped' | 'mitigated';
  targetId: string;
  startTime: number;
  packetsGenerated: number;
  dataCaptured: CapturedData;
  config: AttackConfig;
}

export type AttackType =
  | 'arp_spoof'
  | 'dns_spoof'
  | 'ssl_strip'
  | 'session_hijack'
  | 'packet_sniff'
  | 'fake_login'
  | 'cookie_steal';

export interface AttackConfig {
  aggressiveness: 'low' | 'medium' | 'high';
  duration: number;
  autoStop: boolean;
  stealth: boolean;
}

export interface CapturedData {
  credentials: CredentialEntry[];
  cookies: CookieEntry[];
  sessions: SessionEntry[];
  dnsQueries: DNSQueryEntry[];
  modifiedPackets: number;
  injectedContent: string[];
}

export interface CredentialEntry {
  id: string;
  timestamp: number;
  source: string;
  url: string;
  username: string;
  password: string;
  method: 'post' | 'get' | 'basic_auth' | 'form';
}

export interface CookieEntry {
  id: string;
  timestamp: number;
  domain: string;
  name: string;
  value: string;
  httpOnly: boolean;
  secure: boolean;
  path: string;
}

export interface SessionEntry {
  id: string;
  timestamp: number;
  domain: string;
  sessionId: string;
  userId?: string;
  expiry: number;
}

export interface DNSQueryEntry {
  id: string;
  timestamp: number;
  query: string;
  originalIP: string;
  spoofedIP: boolean;
  resolvedIP: string;
  type: 'A' | 'AAAA' | 'CNAME' | 'MX';
}

export interface MitigationState {
  httpsEverywhere: boolean;
  hsts: boolean;
  certPinning: boolean;
  arpCacheSecurity: boolean;
  vpnActive: boolean;
  dnssec: boolean;
  securityScore: number;
}

export type SocketEvents = {
  'attack:launched': (attack: AttackState) => void;
  'attack:stopped': (attackId: string) => void;
  'attack:mitigated': (attackId: string) => void;
  'packet:captured': (packet: SimulatedPacket) => void;
  'packet:batch': (packets: SimulatedPacket[]) => void;
  'data:captured': (attackId: string, data: Partial<CapturedData>) => void;
  'victim:status': (victim: VictimDevice) => void;
  'topology:update': (devices: VictimDevice[], connections: ConnectionInfo[]) => void;
  'mitigation:update': (state: MitigationState) => void;
  'log:message': (message: LogEntry) => void;
  'stats:update': (stats: DashboardStats) => void;
};

export interface ConnectionInfo {
  from: string;
  to: string;
  type: 'normal' | 'intercepted' | 'blocked';
  bandwidth: number;
  packetCount: number;
}

export interface LogEntry {
  timestamp: number;
  level: 'info' | 'warn' | 'error' | 'success' | 'attack';
  message: string;
  module?: string;
}

export interface DashboardStats {
  totalPackets: number;
  capturedPackets: number;
  modifiedPackets: number;
  activeAttacks: number;
  compromisedDevices: number;
  credentialsCaptured: number;
  packetsPerSecond: number;
  attackTimeline: { time: string; count: number }[];
}
